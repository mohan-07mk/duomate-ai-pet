from PIL import Image, ImageDraw, ImageFont
import os

os.makedirs('assets/icons', exist_ok=True)

# Create 256x256 high-res icon
size = 256
img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
draw = ImageDraw.Draw(img)

# Outer circle background - warm maroon gradient feel
draw.ellipse((8, 8, size-8, size-8), fill=(110, 20, 34, 255), outline=(237, 229, 216, 255), width=6)

# Cute couple silhouette / chibi heart motif
# Heart center
heart_color = (255, 105, 132, 255)
# Draw heart
draw.polygon([
    (128, 195),
    (60, 125),
    (60, 85),
    (95, 60),
    (128, 90),
    (161, 60),
    (196, 85),
    (196, 125)
], fill=heart_color)
draw.pieslice((60, 60, 130, 130), 180, 0, fill=heart_color)
draw.pieslice((126, 60, 196, 130), 180, 0, fill=heart_color)

# Chibi couple heads inside heart
# Boy head (dark hair + cap)
draw.ellipse((85, 95, 125, 135), fill=(255, 224, 208, 255))
draw.arc((82, 92, 128, 138), 180, 360, fill=(30, 24, 20, 255), width=7)

# Girl head (blonde hair)
draw.ellipse((135, 95, 175, 135), fill=(255, 224, 208, 255))
draw.arc((132, 92, 178, 138), 180, 360, fill=(242, 201, 92, 255), width=7)

# DuoMate Pet text accent
# Little white sparkle
draw.ellipse((124, 52, 132, 60), fill=(255, 255, 255, 255))

img.save('assets/icons/icon.png', 'PNG')

# Generate icon.ico with multiple sizes
sizes = [(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
img.save('assets/icons/icon.ico', format='ICO', sizes=sizes)
print('Generated assets/icons/icon.png and assets/icons/icon.ico')
