const si = require('systeminformation');

class HardwareMonitor {
  constructor(onAlert) {
    this.onAlert = onAlert; // Callback for threshold alerts: (type, message)
    this.enabled = true;
    this.intervalId = null;
    this.lastAlertTimes = {
      cpuTemp: 0,
      cpuUsage: 0,
      ramUsage: 0,
      battery: 0
    };
    this.alertCooldownMs = 5 * 60 * 1000; // 5 minute cooldown between duplicate alerts
    this.thresholds = {
      cpuTemp: 80,       // > 80°C
      cpuUsage: 85,      // > 85%
      ramUsage: 90,      // > 90%
      batteryLow: 15     // <= 15%
    };
    this.cachedStats = {
      cpuUsage: '0%',
      cpuTemp: 'Unavailable',
      ramUsage: '0%',
      ramDetails: '',
      gpuName: 'Unavailable',
      gpuUsage: 'Unavailable',
      gpuTemp: 'Unavailable',
      battery: 'Unavailable',
      isCharging: false,
      timestamp: Date.now()
    };
  }

  start(intervalMs = 4000) {
    if (this.intervalId) return;
    this.poll(); // immediate initial read
    this.intervalId = setInterval(() => this.poll(), intervalMs);
  }

  stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }

  setEnabled(val) {
    this.enabled = !!val;
  }

  setThresholds(newThresholds) {
    this.thresholds = { ...this.thresholds, ...newThresholds };
  }

  async poll() {
    try {
      const [load, temp, mem, bat, gfx] = await Promise.all([
        si.currentLoad().catch(() => null),
        si.cpuTemperature().catch(() => null),
        si.mem().catch(() => null),
        si.battery().catch(() => null),
        si.graphics().catch(() => null)
      ]);

      const now = Date.now();
      const stats = { timestamp: now };

      // 1. CPU Usage
      if (load && typeof load.currentLoad === 'number') {
        const cpuPercent = Math.round(load.currentLoad);
        stats.cpuUsage = `${cpuPercent}%`;
        stats.rawCpuUsage = cpuPercent;

        if (this.enabled && cpuPercent >= this.thresholds.cpuUsage) {
          if (now - this.lastAlertTimes.cpuUsage > this.alertCooldownMs) {
            this.lastAlertTimes.cpuUsage = now;
            if (this.onAlert) {
              this.onAlert('cpuUsage', `Mohan! CPU usage romba high-ah irukku, ${cpuPercent}% reach aagiduchu!`);
            }
          }
        }
      } else {
        stats.cpuUsage = 'Unavailable';
        stats.rawCpuUsage = null;
      }

      // 2. CPU Temperature
      if (temp && typeof temp.main === 'number' && temp.main > 0) {
        const cTemp = Math.round(temp.main);
        stats.cpuTemp = `${cTemp}°C`;
        stats.rawCpuTemp = cTemp;

        if (this.enabled && cTemp >= this.thresholds.cpuTemp) {
          if (now - this.lastAlertTimes.cpuTemp > this.alertCooldownMs) {
            this.lastAlertTimes.cpuTemp = now;
            if (this.onAlert) {
              this.onAlert('cpuTemp', 'Mohan! CPU temperature romba high-ah irukku. Check pannunga!');
            }
          }
        }
      } else {
        stats.cpuTemp = 'Unavailable';
        stats.rawCpuTemp = null;
      }

      // 3. RAM Usage
      if (mem && mem.total > 0) {
        const ramPercent = Math.round((mem.active / mem.total) * 100);
        const usedGB = (mem.active / (1024 ** 3)).toFixed(1);
        const totalGB = (mem.total / (1024 ** 3)).toFixed(1);
        stats.ramUsage = `${ramPercent}%`;
        stats.ramDetails = `${usedGB} / ${totalGB} GB`;
        stats.rawRamUsage = ramPercent;

        if (this.enabled && ramPercent >= this.thresholds.ramUsage) {
          if (now - this.lastAlertTimes.ramUsage > this.alertCooldownMs) {
            this.lastAlertTimes.ramUsage = now;
            if (this.onAlert) {
              this.onAlert('ramUsage', `Mohan! RAM usage ${ramPercent}% aagudhu!`);
            }
          }
        }
      } else {
        stats.ramUsage = 'Unavailable';
        stats.rawRamUsage = null;
      }

      // 4. Battery
      if (bat && bat.hasBattery) {
        stats.battery = `${bat.percent}%`;
        stats.isCharging = !!bat.isCharging;
        stats.rawBattery = bat.percent;

        if (this.enabled && !bat.isCharging && bat.percent <= this.thresholds.batteryLow) {
          if (now - this.lastAlertTimes.battery > this.alertCooldownMs) {
            this.lastAlertTimes.battery = now;
            if (this.onAlert) {
              this.onAlert('battery', `Mohan! Battery ${bat.percent}% dhaan irukku. Charger connect pannunga!`);
            }
          }
        }
      } else {
        stats.battery = 'Unavailable (Desktop PC)';
        stats.rawBattery = null;
        stats.isCharging = false;
      }

      // 5. GPU Usage & Temp
      if (gfx && gfx.controllers && gfx.controllers.length > 0) {
        const gpu = gfx.controllers[0];
        stats.gpuName = gpu.model || 'Generic GPU';
        
        if (typeof gpu.utilizationGpu === 'number' && gpu.utilizationGpu >= 0) {
          stats.gpuUsage = `${Math.round(gpu.utilizationGpu)}%`;
        } else {
          stats.gpuUsage = 'Unavailable';
        }

        if (typeof gpu.temperatureGpu === 'number' && gpu.temperatureGpu > 0) {
          stats.gpuTemp = `${Math.round(gpu.temperatureGpu)}°C`;
        } else {
          stats.gpuTemp = 'Unavailable';
        }
      } else {
        stats.gpuName = 'Unavailable';
        stats.gpuUsage = 'Unavailable';
        stats.gpuTemp = 'Unavailable';
      }

      this.cachedStats = stats;
      return stats;
    } catch (err) {
      console.error('HardwareMonitor poll error:', err);
      return this.cachedStats;
    }
  }

  getStats() {
    return this.cachedStats;
  }
}

module.exports = HardwareMonitor;
