import * as THREE from 'three';
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js';
import fs from 'fs';

// Node polyfill for GLTFExporter binary writer
if (typeof FileReader === 'undefined') {
  globalThis.FileReader = class FileReader {
    readAsArrayBuffer(blob) {
      blob.arrayBuffer().then(buf => {
        this.result = buf;
        if (this.onload) this.onload({ target: this });
        if (this.onloadend) this.onloadend({ target: this });
      }).catch(err => {
        if (this.onerror) this.onerror(err);
        if (this.onloadend) this.onloadend({ target: this });
      });
    }
  };
}

// Color Palette matching Reference Image & Prompt
const COLORS = {
  skin: 0xFFE0D0,
  maroon: 0x6E1422,
  maroonDark: 0x520F1A,
  cream: 0xEDE5D8,
  creamDark: 0xD6CDC0,
  white: 0xFDFDFD,
  shoeSole: 0xF5F5F5,
  eyeSclera: 0xFFFFFF,
  eyeIrisBrown: 0x3E1E12,
  eyePupil: 0x180A05,
  blush: 0xFF6584,
  maleHair: 0x221814,
  capBlack: 0x1A1A1A,
  glassesFrame: 0x111111,
  glassesLens: 0x2A2A2A,
  femaleHair: 0xF2C95C,
  mouthPink: 0xC84B60,
  aglet: 0xD0D0D0
};

function createMaterials() {
  return {
    skin: new THREE.MeshStandardMaterial({ color: COLORS.skin, roughness: 0.6, metalness: 0.05 }),
    maroon: new THREE.MeshStandardMaterial({ color: COLORS.maroon, roughness: 0.65, metalness: 0.0 }),
    maroonDark: new THREE.MeshStandardMaterial({ color: COLORS.maroonDark, roughness: 0.7, metalness: 0.0 }),
    cream: new THREE.MeshStandardMaterial({ color: COLORS.cream, roughness: 0.7, metalness: 0.0 }),
    creamDark: new THREE.MeshStandardMaterial({ color: COLORS.creamDark, roughness: 0.75, metalness: 0.0 }),
    white: new THREE.MeshStandardMaterial({ color: COLORS.white, roughness: 0.5, metalness: 0.0 }),
    eyeWhite: new THREE.MeshStandardMaterial({ color: COLORS.eyeSclera, roughness: 0.2, metalness: 0.0 }),
    eyeIris: new THREE.MeshStandardMaterial({ color: COLORS.eyeIrisBrown, roughness: 0.15, metalness: 0.1 }),
    eyePupil: new THREE.MeshStandardMaterial({ color: COLORS.eyePupil, roughness: 0.1, metalness: 0.0 }),
    eyeHighlight: new THREE.MeshBasicMaterial({ color: 0xFFFFFF }),
    blush: new THREE.MeshBasicMaterial({ color: COLORS.blush, transparent: true, opacity: 0.55, depthWrite: false }),
    mouth: new THREE.MeshBasicMaterial({ color: COLORS.mouthPink }),
    maleHair: new THREE.MeshStandardMaterial({ color: COLORS.maleHair, roughness: 0.5, metalness: 0.05 }),
    cap: new THREE.MeshStandardMaterial({ color: COLORS.capBlack, roughness: 0.6, metalness: 0.1 }),
    sunglasses: new THREE.MeshStandardMaterial({ color: COLORS.glassesFrame, roughness: 0.2, metalness: 0.8 }),
    sunglassesLens: new THREE.MeshStandardMaterial({ color: COLORS.glassesLens, roughness: 0.1, metalness: 0.9, transparent: true, opacity: 0.85 }),
    femaleHair: new THREE.MeshStandardMaterial({ color: COLORS.femaleHair, roughness: 0.5, metalness: 0.05 }),
    aglet: new THREE.MeshStandardMaterial({ color: COLORS.aglet, roughness: 0.3, metalness: 0.8 }),
    shoeSole: new THREE.MeshStandardMaterial({ color: COLORS.shoeSole, roughness: 0.8, metalness: 0.0 })
  };
}

function buildEye(materials, isGirl = false) {
  const eyeGroup = new THREE.Group();
  
  const scleraGeo = new THREE.SphereGeometry(0.16, 24, 20);
  scleraGeo.scale(1.0, 1.25, 0.4);
  const sclera = new THREE.Mesh(scleraGeo, materials.eyeWhite);
  eyeGroup.add(sclera);

  const irisGeo = new THREE.SphereGeometry(0.12, 20, 16);
  irisGeo.scale(0.95, 1.15, 0.2);
  const iris = new THREE.Mesh(irisGeo, materials.eyeIris);
  iris.position.set(0, 0, 0.045);
  eyeGroup.add(iris);

  const pupilGeo = new THREE.SphereGeometry(0.065, 16, 12);
  pupilGeo.scale(0.9, 1.1, 0.15);
  const pupil = new THREE.Mesh(pupilGeo, materials.eyePupil);
  pupil.position.set(0, 0, 0.06);
  eyeGroup.add(pupil);

  const hlMainGeo = new THREE.SphereGeometry(0.038, 12, 10);
  hlMainGeo.scale(1.0, 1.0, 0.2);
  const hlMain = new THREE.Mesh(hlMainGeo, materials.eyeHighlight);
  hlMain.position.set(0.045, 0.055, 0.075);
  eyeGroup.add(hlMain);

  const hlSubGeo = new THREE.SphereGeometry(0.018, 10, 8);
  hlSubGeo.scale(1.0, 1.0, 0.2);
  const hlSub = new THREE.Mesh(hlSubGeo, materials.eyeHighlight);
  hlSub.position.set(-0.04, -0.04, 0.075);
  eyeGroup.add(hlSub);

  if (isGirl) {
    const lashCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.14, 0.13, 0.04),
      new THREE.Vector3(0.0, 0.21, 0.05),
      new THREE.Vector3(0.15, 0.17, 0.06),
      new THREE.Vector3(0.22, 0.22, 0.05)
    ]);
    const lashGeo = new THREE.TubeGeometry(lashCurve, 12, 0.014, 6, false);
    const lash = new THREE.Mesh(lashGeo, materials.cap);
    eyeGroup.add(lash);
  }

  const lidGeo = new THREE.SphereGeometry(0.17, 24, 12, 0, Math.PI * 2, 0, Math.PI * 0.5);
  lidGeo.scale(1.02, 1.28, 0.45);
  const eyelid = new THREE.Mesh(lidGeo, materials.skin);
  eyelid.position.set(0, 0.05, 0.01);
  eyelid.rotation.x = -Math.PI * 0.5;
  eyelid.name = 'eyelid';
  eyeGroup.add(eyelid);

  return eyeGroup;
}

function buildSneaker(materials) {
  const shoeGroup = new THREE.Group();

  const soleGeo = new THREE.BoxGeometry(0.28, 0.10, 0.52);
  const sole = new THREE.Mesh(soleGeo, materials.shoeSole);
  sole.position.set(0, 0.05, 0.04);
  shoeGroup.add(sole);

  const upperGeo = new THREE.BoxGeometry(0.26, 0.18, 0.48);
  const upper = new THREE.Mesh(upperGeo, materials.maroon);
  upper.position.set(0, 0.16, 0.03);
  shoeGroup.add(upper);

  const toeGeo = new THREE.CylinderGeometry(0.13, 0.135, 0.14, 16, 1, false, -Math.PI*0.5, Math.PI);
  toeGeo.scale(1.0, 1.0, 0.85);
  toeGeo.rotateZ(Math.PI * 0.5);
  const toeCap = new THREE.Mesh(toeGeo, materials.white);
  toeCap.position.set(0, 0.13, 0.22);
  shoeGroup.add(toeCap);

  for (let i = 0; i < 3; i++) {
    const laceGeo = new THREE.BoxGeometry(0.18, 0.02, 0.04);
    const lace = new THREE.Mesh(laceGeo, materials.white);
    lace.position.set(0, 0.25, 0.02 + i * 0.07);
    lace.rotation.x = -0.2;
    shoeGroup.add(lace);
  }

  const stripeGeo = new THREE.BoxGeometry(0.27, 0.02, 0.32);
  const stripe = new THREE.Mesh(stripeGeo, materials.white);
  stripe.position.set(0, 0.15, -0.01);
  shoeGroup.add(stripe);

  return shoeGroup;
}

function buildMohan(materials) {
  const root = new THREE.Group();
  root.name = 'Mohan';

  const hips = new THREE.Group();
  hips.name = 'Hips';
  hips.position.set(0, 1.15, 0);
  root.add(hips);

  const pelvisGeo = new THREE.CylinderGeometry(0.28, 0.26, 0.25, 20);
  const pelvis = new THREE.Mesh(pelvisGeo, materials.cream);
  hips.add(pelvis);

  const spine = new THREE.Group();
  spine.name = 'Spine';
  spine.position.set(0, 0.18, 0);
  hips.add(spine);

  const chest = new THREE.Group();
  chest.name = 'Chest';
  chest.position.set(0, 0.32, 0);
  spine.add(chest);

  const hoodieGeo = new THREE.CylinderGeometry(0.36, 0.32, 0.55, 24);
  hoodieGeo.scale(1.15, 1.0, 0.9);
  const hoodie = new THREE.Mesh(hoodieGeo, materials.maroon);
  chest.add(hoodie);

  const pocketGeo = new THREE.BoxGeometry(0.38, 0.22, 0.12);
  const pocket = new THREE.Mesh(pocketGeo, materials.maroonDark);
  pocket.position.set(0, -0.12, 0.28);
  pocket.rotation.x = -0.1;
  chest.add(pocket);

  for (const side of [-1, 1]) {
    const stringGeo = new THREE.CylinderGeometry(0.012, 0.012, 0.35, 8);
    const cord = new THREE.Mesh(stringGeo, materials.white);
    cord.position.set(side * 0.11, -0.05, 0.34);
    chest.add(cord);

    const agletGeo = new THREE.CylinderGeometry(0.015, 0.015, 0.05, 8);
    const aglet = new THREE.Mesh(agletGeo, materials.aglet);
    aglet.position.set(side * 0.11, -0.23, 0.34);
    chest.add(aglet);
  }

  const hoodGeo = new THREE.TorusGeometry(0.32, 0.12, 12, 24, Math.PI * 1.5);
  hoodGeo.rotateX(Math.PI * 0.5);
  hoodGeo.rotateZ(Math.PI * 0.25);
  const hood = new THREE.Mesh(hoodGeo, materials.maroonDark);
  hood.position.set(0, 0.22, -0.08);
  chest.add(hood);

  const neck = new THREE.Group();
  neck.name = 'Neck';
  neck.position.set(0, 0.35, 0);
  chest.add(neck);

  const neckMeshGeo = new THREE.CylinderGeometry(0.14, 0.16, 0.18, 16);
  const neckMesh = new THREE.Mesh(neckMeshGeo, materials.skin);
  neck.add(neckMesh);

  const head = new THREE.Group();
  head.name = 'Head';
  head.position.set(0, 0.42, 0);
  neck.add(head);

  const headGeo = new THREE.SphereGeometry(0.62, 32, 28);
  headGeo.scale(1.08, 0.98, 1.0);
  const headMesh = new THREE.Mesh(headGeo, materials.skin);
  head.add(headMesh);

  for (const side of [-1, 1]) {
    const earGeo = new THREE.SphereGeometry(0.12, 16, 12);
    earGeo.scale(0.5, 1.0, 0.8);
    const ear = new THREE.Mesh(earGeo, materials.skin);
    ear.position.set(side * 0.65, -0.04, -0.08);
    head.add(ear);
  }

  const noseGeo = new THREE.SphereGeometry(0.042, 12, 10);
  const nose = new THREE.Mesh(noseGeo, materials.skin);
  nose.position.set(0, -0.04, 0.62);
  head.add(nose);

  const leftEye = buildEye(materials, false);
  leftEye.name = 'LeftEye';
  leftEye.position.set(0.24, 0.04, 0.55);
  leftEye.rotation.y = 0.22;
  head.add(leftEye);

  const rightEye = buildEye(materials, false);
  rightEye.name = 'RightEye';
  rightEye.position.set(-0.24, 0.04, 0.55);
  rightEye.rotation.y = -0.22;
  head.add(rightEye);

  for (const side of [-1, 1]) {
    const browGeo = new THREE.BoxGeometry(0.18, 0.032, 0.02);
    const brow = new THREE.Mesh(browGeo, materials.maleHair);
    brow.position.set(side * 0.24, 0.25, 0.57);
    brow.rotation.z = side * -0.15;
    brow.rotation.y = side * 0.2;
    head.add(brow);
  }

  const mouthGeo = new THREE.TorusGeometry(0.08, 0.02, 8, 16, Math.PI);
  mouthGeo.rotateX(Math.PI);
  const mouth = new THREE.Mesh(mouthGeo, materials.mouth);
  mouth.name = 'Mouth';
  mouth.position.set(0, -0.22, 0.57);
  head.add(mouth);

  for (const side of [-1, 1]) {
    const blushGeo = new THREE.CircleGeometry(0.11, 20);
    const blushMesh = new THREE.Mesh(blushGeo, materials.blush);
    blushMesh.position.set(side * 0.38, -0.14, 0.51);
    blushMesh.rotation.y = side * 0.6;
    head.add(blushMesh);
  }

  const hairBangsGroup = new THREE.Group();
  for (let i = -3; i <= 3; i++) {
    const tuftGeo = new THREE.ConeGeometry(0.10, 0.26, 8);
    tuftGeo.rotateZ(Math.PI + (i * 0.12));
    const tuft = new THREE.Mesh(tuftGeo, materials.maleHair);
    tuft.position.set(i * 0.12, 0.34, 0.52 - Math.abs(i) * 0.04);
    hairBangsGroup.add(tuft);
  }
  head.add(hairBangsGroup);

  const capGroup = new THREE.Group();
  capGroup.position.set(0, 0.22, -0.05);

  const capDomeGeo = new THREE.SphereGeometry(0.66, 28, 20, 0, Math.PI * 2, 0, Math.PI * 0.55);
  const capDome = new THREE.Mesh(capDomeGeo, materials.cap);
  capGroup.add(capDome);

  const visorGeo = new THREE.CylinderGeometry(0.72, 0.72, 0.035, 24, 1, false, -Math.PI * 0.38, Math.PI * 0.76);
  visorGeo.rotateY(Math.PI * 0.5);
  const visor = new THREE.Mesh(visorGeo, materials.cap);
  visor.position.set(0, 0.02, 0.22);
  visor.rotation.x = -0.15;
  capGroup.add(visor);

  const btnGeo = new THREE.SphereGeometry(0.04, 12, 8);
  const capBtn = new THREE.Mesh(btnGeo, materials.cap);
  capBtn.position.set(0, 0.68, 0);
  capGroup.add(capBtn);

  const glassesGroup = new THREE.Group();
  glassesGroup.position.set(0, 0.25, 0.55);
  glassesGroup.rotation.x = -0.28;

  for (const side of [-1, 1]) {
    const lensGeo = new THREE.BoxGeometry(0.24, 0.14, 0.02);
    const lens = new THREE.Mesh(lensGeo, materials.sunglassesLens);
    lens.position.set(side * 0.16, 0, 0);
    glassesGroup.add(lens);

    const frameGeo = new THREE.BoxGeometry(0.26, 0.16, 0.025);
    const frame = new THREE.Mesh(frameGeo, materials.sunglasses);
    frame.position.set(side * 0.16, 0, -0.005);
    glassesGroup.add(frame);
  }
  const bridgeGeo = new THREE.BoxGeometry(0.12, 0.03, 0.025);
  const bridge = new THREE.Mesh(bridgeGeo, materials.sunglasses);
  bridge.position.set(0, 0.03, 0);
  glassesGroup.add(bridge);

  capGroup.add(glassesGroup);
  head.add(capGroup);

  for (const side of [-1, 1]) {
    const isLeft = side === 1;
    const prefix = isLeft ? 'Left' : 'Right';

    const shoulder = new THREE.Group();
    shoulder.name = `${prefix}Shoulder`;
    shoulder.position.set(side * 0.40, 0.15, 0);
    chest.add(shoulder);

    const upperArm = new THREE.Group();
    upperArm.name = `${prefix}UpperArm`;
    upperArm.position.set(side * 0.08, -0.06, 0);
    shoulder.add(upperArm);

    const upperArmMeshGeo = new THREE.CylinderGeometry(0.12, 0.11, 0.38, 16);
    const upperArmMesh = new THREE.Mesh(upperArmMeshGeo, materials.maroon);
    upperArmMesh.position.set(0, -0.16, 0);
    upperArm.add(upperArmMesh);

    const forearm = new THREE.Group();
    forearm.name = `${prefix}Forearm`;
    forearm.position.set(0, -0.34, 0);
    upperArm.add(forearm);

    const forearmMeshGeo = new THREE.CylinderGeometry(0.105, 0.095, 0.34, 16);
    const forearmMesh = new THREE.Mesh(forearmMeshGeo, materials.maroon);
    forearmMesh.position.set(0, -0.15, 0);
    forearm.add(forearmMesh);

    const cuffGeo = new THREE.CylinderGeometry(0.10, 0.10, 0.06, 16);
    const cuff = new THREE.Mesh(cuffGeo, materials.cream);
    cuff.position.set(0, -0.32, 0);
    forearm.add(cuff);

    const hand = new THREE.Group();
    hand.name = `${prefix}Hand`;
    hand.position.set(0, -0.38, 0);
    forearm.add(hand);

    const handGeo = new THREE.SphereGeometry(0.10, 16, 12);
    handGeo.scale(1.0, 1.2, 0.7);
    const handMesh = new THREE.Mesh(handGeo, materials.skin);
    handMesh.position.set(0, -0.06, 0);
    hand.add(handMesh);

    const thumbGeo = new THREE.SphereGeometry(0.045, 10, 8);
    thumbGeo.scale(0.8, 1.4, 0.8);
    const thumb = new THREE.Mesh(thumbGeo, materials.skin);
    thumb.position.set(side * -0.06, -0.04, 0.05);
    thumb.rotation.z = side * 0.4;
    hand.add(thumb);
  }

  for (const side of [-1, 1]) {
    const isLeft = side === 1;
    const prefix = isLeft ? 'Left' : 'Right';

    const thigh = new THREE.Group();
    thigh.name = `${prefix}Thigh`;
    thigh.position.set(side * 0.19, -0.12, 0);
    hips.add(thigh);

    const thighMeshGeo = new THREE.CylinderGeometry(0.15, 0.13, 0.48, 16);
    const thighMesh = new THREE.Mesh(thighMeshGeo, materials.cream);
    thighMesh.position.set(0, -0.22, 0);
    thigh.add(thighMesh);

    const shin = new THREE.Group();
    shin.name = `${prefix}Shin`;
    shin.position.set(0, -0.46, 0);
    thigh.add(shin);

    const shinMeshGeo = new THREE.CylinderGeometry(0.13, 0.115, 0.44, 16);
    const shinMesh = new THREE.Mesh(shinMeshGeo, materials.cream);
    shinMesh.position.set(0, -0.20, 0);
    shin.add(shinMesh);

    const foot = new THREE.Group();
    foot.name = `${prefix}Foot`;
    foot.position.set(0, -0.42, 0);
    shin.add(foot);

    const sneaker = buildSneaker(materials);
    foot.add(sneaker);
  }

  return root;
}

function buildCompanion(materials) {
  const root = new THREE.Group();
  root.name = 'Companion';

  const hips = new THREE.Group();
  hips.name = 'Hips';
  hips.position.set(0, 1.12, 0);
  root.add(hips);

  const pelvisGeo = new THREE.CylinderGeometry(0.26, 0.24, 0.24, 20);
  const pelvis = new THREE.Mesh(pelvisGeo, materials.cream);
  hips.add(pelvis);

  const spine = new THREE.Group();
  spine.name = 'Spine';
  spine.position.set(0, 0.17, 0);
  hips.add(spine);

  const chest = new THREE.Group();
  chest.name = 'Chest';
  chest.position.set(0, 0.30, 0);
  spine.add(chest);

  const hoodieGeo = new THREE.CylinderGeometry(0.34, 0.30, 0.52, 24);
  hoodieGeo.scale(1.12, 1.0, 0.88);
  const hoodie = new THREE.Mesh(hoodieGeo, materials.maroon);
  chest.add(hoodie);

  const pocketGeo = new THREE.BoxGeometry(0.35, 0.20, 0.11);
  const pocket = new THREE.Mesh(pocketGeo, materials.maroonDark);
  pocket.position.set(0, -0.11, 0.26);
  pocket.rotation.x = -0.1;
  chest.add(pocket);

  for (const side of [-1, 1]) {
    const stringGeo = new THREE.CylinderGeometry(0.011, 0.011, 0.34, 8);
    const cord = new THREE.Mesh(stringGeo, materials.white);
    cord.position.set(side * 0.10, -0.05, 0.32);
    chest.add(cord);

    const agletGeo = new THREE.CylinderGeometry(0.014, 0.014, 0.048, 8);
    const aglet = new THREE.Mesh(agletGeo, materials.aglet);
    aglet.position.set(side * 0.10, -0.22, 0.32);
    chest.add(aglet);
  }

  const hoodGeo = new THREE.TorusGeometry(0.30, 0.11, 12, 24, Math.PI * 1.5);
  hoodGeo.rotateX(Math.PI * 0.5);
  hoodGeo.rotateZ(Math.PI * 0.25);
  const hood = new THREE.Mesh(hoodGeo, materials.maroonDark);
  hood.position.set(0, 0.21, -0.08);
  chest.add(hood);

  const neck = new THREE.Group();
  neck.name = 'Neck';
  neck.position.set(0, 0.34, 0);
  chest.add(neck);

  const neckMeshGeo = new THREE.CylinderGeometry(0.13, 0.15, 0.17, 16);
  const neckMesh = new THREE.Mesh(neckMeshGeo, materials.skin);
  neck.add(neckMesh);

  const head = new THREE.Group();
  head.name = 'Head';
  head.position.set(0, 0.40, 0);
  neck.add(head);

  const headGeo = new THREE.SphereGeometry(0.60, 32, 28);
  headGeo.scale(1.06, 0.98, 1.0);
  const headMesh = new THREE.Mesh(headGeo, materials.skin);
  head.add(headMesh);

  for (const side of [-1, 1]) {
    const earGeo = new THREE.SphereGeometry(0.11, 16, 12);
    earGeo.scale(0.5, 1.0, 0.8);
    const ear = new THREE.Mesh(earGeo, materials.skin);
    ear.position.set(side * 0.63, -0.04, -0.08);
    head.add(ear);
  }

  const noseGeo = new THREE.SphereGeometry(0.038, 12, 10);
  const nose = new THREE.Mesh(noseGeo, materials.skin);
  nose.position.set(0, -0.04, 0.60);
  head.add(nose);

  const leftEye = buildEye(materials, true);
  leftEye.name = 'LeftEye';
  leftEye.position.set(0.23, 0.04, 0.54);
  leftEye.rotation.y = 0.22;
  head.add(leftEye);

  const rightEye = buildEye(materials, true);
  rightEye.name = 'RightEye';
  rightEye.position.set(-0.23, 0.04, 0.54);
  rightEye.rotation.y = -0.22;
  head.add(rightEye);

  for (const side of [-1, 1]) {
    const browGeo = new THREE.BoxGeometry(0.17, 0.026, 0.02);
    const brow = new THREE.Mesh(browGeo, materials.femaleHair);
    brow.position.set(side * 0.23, 0.25, 0.56);
    brow.rotation.z = side * -0.12;
    brow.rotation.y = side * 0.2;
    head.add(brow);
  }

  const mouthGeo = new THREE.TorusGeometry(0.085, 0.02, 8, 16, Math.PI);
  mouthGeo.rotateX(Math.PI);
  const mouth = new THREE.Mesh(mouthGeo, materials.mouth);
  mouth.name = 'Mouth';
  mouth.position.set(0, -0.21, 0.56);
  head.add(mouth);

  for (const side of [-1, 1]) {
    const blushGeo = new THREE.CircleGeometry(0.13, 20);
    const blushMesh = new THREE.Mesh(blushGeo, materials.blush);
    blushMesh.position.set(side * 0.36, -0.13, 0.50);
    blushMesh.rotation.y = side * 0.58;
    head.add(blushMesh);
  }

  const hairGroup = new THREE.Group();
  hairGroup.name = 'BlondeHair';

  const crownGeo = new THREE.SphereGeometry(0.67, 28, 22);
  crownGeo.scale(1.08, 1.05, 1.05);
  const crown = new THREE.Mesh(crownGeo, materials.femaleHair);
  crown.position.set(0, 0.06, -0.10);
  hairGroup.add(crown);

  for (let i = -3; i <= 3; i++) {
    const bangGeo = new THREE.ConeGeometry(0.12, 0.35, 10);
    bangGeo.rotateZ(Math.PI + (i * 0.15));
    const bang = new THREE.Mesh(bangGeo, materials.femaleHair);
    bang.position.set(i * 0.13, 0.38, 0.50 - Math.abs(i) * 0.04);
    hairGroup.add(bang);
  }

  for (const side of [-1, 1]) {
    const sideCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(side * 0.55, 0.28, 0.20),
      new THREE.Vector3(side * 0.62, 0.00, 0.32),
      new THREE.Vector3(side * 0.58, -0.32, 0.28),
      new THREE.Vector3(side * 0.50, -0.55, 0.20)
    ]);
    const sideGeo = new THREE.TubeGeometry(sideCurve, 16, 0.075, 8, false);
    const sideLock = new THREE.Mesh(sideGeo, materials.femaleHair);
    hairGroup.add(sideLock);
  }

  for (let b = -2; b <= 2; b++) {
    const backCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(b * 0.18, 0.10, -0.55),
      new THREE.Vector3(b * 0.22, -0.25, -0.50),
      new THREE.Vector3(b * 0.20, -0.65, -0.35)
    ]);
    const backGeo = new THREE.TubeGeometry(backCurve, 12, 0.09, 8, false);
    const backLock = new THREE.Mesh(backGeo, materials.femaleHair);
    hairGroup.add(backLock);
  }

  head.add(hairGroup);

  for (const side of [-1, 1]) {
    const isLeft = side === 1;
    const prefix = isLeft ? 'Left' : 'Right';

    const shoulder = new THREE.Group();
    shoulder.name = `${prefix}Shoulder`;
    shoulder.position.set(side * 0.38, 0.14, 0);
    chest.add(shoulder);

    const upperArm = new THREE.Group();
    upperArm.name = `${prefix}UpperArm`;
    upperArm.position.set(side * 0.07, -0.06, 0);
    shoulder.add(upperArm);

    const upperArmMeshGeo = new THREE.CylinderGeometry(0.11, 0.10, 0.36, 16);
    const upperArmMesh = new THREE.Mesh(upperArmMeshGeo, materials.maroon);
    upperArmMesh.position.set(0, -0.15, 0);
    upperArm.add(upperArmMesh);

    const forearm = new THREE.Group();
    forearm.name = `${prefix}Forearm`;
    forearm.position.set(0, -0.32, 0);
    upperArm.add(forearm);

    const forearmMeshGeo = new THREE.CylinderGeometry(0.095, 0.088, 0.32, 16);
    const forearmMesh = new THREE.Mesh(forearmMeshGeo, materials.maroon);
    forearmMesh.position.set(0, -0.14, 0);
    forearm.add(forearmMesh);

    const cuffGeo = new THREE.CylinderGeometry(0.092, 0.092, 0.055, 16);
    const cuff = new THREE.Mesh(cuffGeo, materials.cream);
    cuff.position.set(0, -0.30, 0);
    forearm.add(cuff);

    const hand = new THREE.Group();
    hand.name = `${prefix}Hand`;
    hand.position.set(0, -0.36, 0);
    forearm.add(hand);

    const handGeo = new THREE.SphereGeometry(0.092, 16, 12);
    handGeo.scale(1.0, 1.2, 0.68);
    const handMesh = new THREE.Mesh(handGeo, materials.skin);
    handMesh.position.set(0, -0.055, 0);
    hand.add(handMesh);

    const thumbGeo = new THREE.SphereGeometry(0.042, 10, 8);
    thumbGeo.scale(0.8, 1.4, 0.8);
    const thumb = new THREE.Mesh(thumbGeo, materials.skin);
    thumb.position.set(side * -0.055, -0.038, 0.045);
    thumb.rotation.z = side * 0.4;
    hand.add(thumb);
  }

  for (const side of [-1, 1]) {
    const isLeft = side === 1;
    const prefix = isLeft ? 'Left' : 'Right';

    const thigh = new THREE.Group();
    thigh.name = `${prefix}Thigh`;
    thigh.position.set(side * 0.18, -0.11, 0);
    hips.add(thigh);

    const thighMeshGeo = new THREE.CylinderGeometry(0.14, 0.12, 0.46, 16);
    const thighMesh = new THREE.Mesh(thighMeshGeo, materials.cream);
    thighMesh.position.set(0, -0.21, 0);
    thigh.add(thighMesh);

    const shin = new THREE.Group();
    shin.name = `${prefix}Shin`;
    shin.position.set(0, -0.44, 0);
    thigh.add(shin);

    const shinMeshGeo = new THREE.CylinderGeometry(0.12, 0.108, 0.42, 16);
    const shinMesh = new THREE.Mesh(shinMeshGeo, materials.cream);
    shinMesh.position.set(0, -0.19, 0);
    shin.add(shinMesh);

    const foot = new THREE.Group();
    foot.name = `${prefix}Foot`;
    foot.position.set(0, -0.40, 0);
    shin.add(foot);

    const sneaker = buildSneaker(materials);
    foot.add(sneaker);
  }

  return root;
}

// Helper: Convert array of Euler angles to Quaternion Keyframe Track
function eulersToQuaternionTrack(nodeName, times, eulerArray) {
  const quats = [];
  const euler = new THREE.Euler();
  const quat = new THREE.Quaternion();

  for (let i = 0; i < eulerArray.length; i += 3) {
    euler.set(eulerArray[i], eulerArray[i+1], eulerArray[i+2]);
    quat.setFromEuler(euler);
    quats.push(quat.x, quat.y, quat.z, quat.w);
  }

  return new THREE.QuaternionKeyframeTrack(`${nodeName}.quaternion`, times, quats);
}

// Generate Standard glTF 2.0 Animation Clips with Quaternions
function generateClips(characterName) {
  const isMale = characterName === 'Mohan';
  const armSign = isMale ? -1 : 1;
  const innerArm = isMale ? 'Right' : 'Left';
  const lookDir = isMale ? 1 : -1;
  const hugArmAngle = isMale ? -0.4 : 0.4;
  const clips = [];

  // 1. Idle
  clips.push(new THREE.AnimationClip('idle', 2.0, [
    new THREE.VectorKeyframeTrack('Chest.position', [0, 1.0, 2.0], [
      0, 0.32, 0,
      0, 0.335, 0,
      0, 0.32, 0
    ]),
    eulersToQuaternionTrack('Chest', [0, 1.0, 2.0], [
      0, 0, 0,
      -0.02, 0, 0,
      0, 0, 0
    ]),
    eulersToQuaternionTrack('Head', [0, 1.0, 2.0], [
      0, 0, 0,
      0.02, 0, 0.015,
      0, 0, 0
    ]),
    eulersToQuaternionTrack('LeftUpperArm', [0, 1.0, 2.0], [
      0, 0, 0.1,
      0, 0, 0.14,
      0, 0, 0.1
    ]),
    eulersToQuaternionTrack('RightUpperArm', [0, 1.0, 2.0], [
      0, 0, -0.1,
      0, 0, -0.14,
      0, 0, -0.1
    ])
  ]));

  // 2. Blink
  clips.push(new THREE.AnimationClip('blink', 0.35, [
    eulersToQuaternionTrack('LeftEye/eyelid', [0, 0.12, 0.22, 0.35], [
      -Math.PI * 0.5, 0, 0,
      0, 0, 0,
      0, 0, 0,
      -Math.PI * 0.5, 0, 0
    ]),
    eulersToQuaternionTrack('RightEye/eyelid', [0, 0.12, 0.22, 0.35], [
      -Math.PI * 0.5, 0, 0,
      0, 0, 0,
      0, 0, 0,
      -Math.PI * 0.5, 0, 0
    ])
  ]));

  // 3. Smile
  clips.push(new THREE.AnimationClip('smile', 1.0, [
    eulersToQuaternionTrack('Head', [0, 0.3, 0.8, 1.0], [
      0, 0, 0,
      -0.05, 0, 0,
      -0.05, 0, 0,
      0, 0, 0
    ]),
    new THREE.VectorKeyframeTrack('Mouth.scale', [0, 0.3, 0.8, 1.0], [
      1,1,1,
      1.3,1.2,1,
      1.3,1.2,1,
      1,1,1
    ])
  ]));

  // 4. Look At Each Other
  clips.push(new THREE.AnimationClip('look_at_each_other', 1.5, [
    eulersToQuaternionTrack('Head', [0, 0.5, 1.2, 1.5], [
      0, 0, 0,
      0, lookDir * 0.45, lookDir * 0.08,
      0, lookDir * 0.45, lookDir * 0.08,
      0, 0, 0
    ])
  ]));

  // 5. Walk (1.0s)
  const walkTimes = [0, 0.25, 0.5, 0.75, 1.0];
  clips.push(new THREE.AnimationClip('walk', 1.0, [
    new THREE.VectorKeyframeTrack('Hips.position', walkTimes, [
      0, 1.15, 0,
      0, 1.19, 0,
      0, 1.15, 0,
      0, 1.19, 0,
      0, 1.15, 0
    ]),
    eulersToQuaternionTrack('LeftThigh', walkTimes, [
      0,0,0,  0.45,0,0,  0,0,0,  -0.45,0,0,  0,0,0
    ]),
    eulersToQuaternionTrack('RightThigh', walkTimes, [
      0,0,0,  -0.45,0,0,  0,0,0,  0.45,0,0,  0,0,0
    ]),
    eulersToQuaternionTrack('LeftShin', walkTimes, [
      0,0,0,  -0.3,0,0,  0.1,0,0,  -0.05,0,0,  0,0,0
    ]),
    eulersToQuaternionTrack('RightShin', walkTimes, [
      0,0,0,  -0.05,0,0,  0.1,0,0,  -0.3,0,0,  0,0,0
    ]),
    eulersToQuaternionTrack('LeftUpperArm', walkTimes, [
      0,0,0.1,  -0.35,0,0.1,  0,0,0.1,  0.35,0,0.1,  0,0,0.1
    ]),
    eulersToQuaternionTrack('RightUpperArm', walkTimes, [
      0,0,-0.1,  0.35,0,-0.1,  0,0,-0.1,  -0.35,0,-0.1,  0,0,-0.1
    ])
  ]));

  // 6. Sit (1.5s)
  clips.push(new THREE.AnimationClip('sit', 1.5, [
    new THREE.VectorKeyframeTrack('Hips.position', [0, 0.7, 1.5], [
      0, 1.15, 0,
      0, 0.65, -0.2,
      0, 0.58, -0.25
    ]),
    eulersToQuaternionTrack('LeftThigh', [0, 0.7, 1.5], [
      0,0,0,  1.45,0,0,  1.55,0,0
    ]),
    eulersToQuaternionTrack('RightThigh', [0, 0.7, 1.5], [
      0,0,0,  1.45,0,0,  1.55,0,0
    ]),
    eulersToQuaternionTrack('LeftShin', [0, 0.7, 1.5], [
      0,0,0,  -1.35,0,0,  -1.45,0,0
    ]),
    eulersToQuaternionTrack('RightShin', [0, 0.7, 1.5], [
      0,0,0,  -1.35,0,0,  -1.45,0,0
    ]),
    eulersToQuaternionTrack('LeftUpperArm', [0, 0.7, 1.5], [
      0,0,0.1,  0.3,0,0.1,  0.5,0,0.1
    ]),
    eulersToQuaternionTrack('RightUpperArm', [0, 0.7, 1.5], [
      0,0,-0.1,  0.3,0,-0.1,  0.5,0,-0.1
    ])
  ]));

  // 7. Hug (2.0s)
  clips.push(new THREE.AnimationClip('hug', 2.0, [
    eulersToQuaternionTrack('Chest', [0, 0.6, 1.6, 2.0], [
      0,0,0,  0,hugArmAngle,0,  0,hugArmAngle,0,  0,0,0
    ]),
    eulersToQuaternionTrack('LeftUpperArm', [0, 0.6, 1.6, 2.0], [
      0,0,0.1,  0,0,0.6,  0,0,0.65,  0,0,0.1
    ]),
    eulersToQuaternionTrack('RightUpperArm', [0, 0.6, 1.6, 2.0], [
      0,0,-0.1,  0,0,-0.6,  0,0,-0.65,  0,0,-0.1
    ]),
    eulersToQuaternionTrack('LeftForearm', [0, 0.6, 1.6, 2.0], [
      0,0,0,  0,0.8,0,  0,0.85,0,  0,0,0
    ]),
    eulersToQuaternionTrack('RightForearm', [0, 0.6, 1.6, 2.0], [
      0,0,0,  0,-0.8,0,  0,-0.85,0,  0,0,0
    ]),
    eulersToQuaternionTrack('Head', [0, 0.6, 1.6, 2.0], [
      0,0,0,  0,0,hugArmAngle * 0.4,  0,0,hugArmAngle * 0.4,  0,0,0
    ])
  ]));

  // 8. Hold Hands (1.5s)
  clips.push(new THREE.AnimationClip('hold_hands', 1.5, [
    eulersToQuaternionTrack(`${innerArm}UpperArm`, [0, 0.5, 1.2, 1.5], [
      0,0,armSign * 0.1,
      0,0,armSign * 0.35,
      0,0,armSign * 0.35,
      0,0,armSign * 0.1
    ]),
    eulersToQuaternionTrack(`${innerArm}Forearm`, [0, 0.5, 1.2, 1.5], [
      0,0,0,  -0.25,0,0,  -0.25,0,0,  0,0,0
    ]),
    eulersToQuaternionTrack('Head', [0, 0.5, 1.2, 1.5], [
      0,0,0,  0,-armSign * 0.25,0,  0,-armSign * 0.25,0,  0,0,0
    ])
  ]));

  // 9. Blush (1.5s)
  clips.push(new THREE.AnimationClip('blush', 1.5, [
    eulersToQuaternionTrack('Head', [0, 0.4, 1.1, 1.5], [
      0,0,0,  0.12,0,-0.08,  0.12,0,-0.08,  0,0,0
    ]),
    new THREE.VectorKeyframeTrack('Mouth.scale', [0, 0.4, 1.1, 1.5], [
      1,1,1,  1.15,1.1,1,  1.15,1.1,1,  1,1,1
    ])
  ]));

  // 10. Couple Walk (1.2s)
  const cWalkTimes = [0, 0.3, 0.6, 0.9, 1.2];
  clips.push(new THREE.AnimationClip('couple_walk', 1.2, [
    new THREE.VectorKeyframeTrack('Hips.position', cWalkTimes, [
      0, 1.15, 0,
      0, 1.18, 0,
      0, 1.15, 0,
      0, 1.18, 0,
      0, 1.15, 0
    ]),
    eulersToQuaternionTrack('LeftThigh', cWalkTimes, [
      0,0,0,  0.4,0,0,  0,0,0,  -0.4,0,0,  0,0,0
    ]),
    eulersToQuaternionTrack('RightThigh', cWalkTimes, [
      0,0,0,  -0.4,0,0,  0,0,0,  0.4,0,0,  0,0,0
    ]),
    eulersToQuaternionTrack('LeftShin', cWalkTimes, [
      0,0,0,  -0.25,0,0,  0.08,0,0,  -0.04,0,0,  0,0,0
    ]),
    eulersToQuaternionTrack('RightShin', cWalkTimes, [
      0,0,0,  -0.04,0,0,  0.08,0,0,  -0.25,0,0,  0,0,0
    ]),
    eulersToQuaternionTrack(`${innerArm}UpperArm`, cWalkTimes, [
      0,0,armSign * 0.28,
      0,0,armSign * 0.28,
      0,0,armSign * 0.28,
      0,0,armSign * 0.28,
      0,0,armSign * 0.28
    ])
  ]));

  return clips;
}

function exportToGLB(scene, animations, outputPath) {
  return new Promise((resolve, reject) => {
    const exporter = new GLTFExporter();
    exporter.parse(
      scene,
      (gltf) => {
        const buffer = Buffer.from(gltf);
        fs.writeFileSync(outputPath, buffer);
        console.log(`Exported ${outputPath} (${buffer.length} bytes, ${animations.length} animations)`);
        resolve(buffer);
      },
      (error) => {
        console.error(`Export failed for ${outputPath}:`, error);
        reject(error);
      },
      { binary: true, animations: animations }
    );
  });
}

async function main() {
  console.log('Generating 3D characters for DuoMate Desktop Pet with valid glTF 2.0 Quaternion tracks...');
  const materials = createMaterials();

  // 1. Build Mohan
  const mohanScene = new THREE.Scene();
  const mohan = buildMohan(materials);
  mohanScene.add(mohan);
  const mohanClips = generateClips('Mohan');
  await exportToGLB(mohanScene, mohanClips, 'assets/models/mohan.glb');

  // 2. Build AI Companion
  const companionScene = new THREE.Scene();
  const companion = buildCompanion(materials);
  companionScene.add(companion);
  const companionClips = generateClips('Companion');
  await exportToGLB(companionScene, companionClips, 'assets/models/companion.glb');

  // 3. Build Couple Scene
  const coupleScene = new THREE.Scene();
  const mohanCouple = buildMohan(materials);
  mohanCouple.position.set(-0.55, 0, 0);
  const companionCouple = buildCompanion(materials);
  companionCouple.position.set(0.55, 0, 0);
  coupleScene.add(mohanCouple);
  coupleScene.add(companionCouple);
  await exportToGLB(coupleScene, [...mohanClips, ...companionClips], 'assets/models/couple_scene.glb');

  console.log('All 3D character assets generated cleanly with 0 warnings!');
}

main().catch(console.error);
