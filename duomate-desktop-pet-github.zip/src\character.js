// DuoMate 3D Rigged Characters & Animation Controller
const COLORS = {
  skin: 0xFFE0D0,
  maroon: 0x6E1422,
  maroonDark: 0x520F1A,
  cream: 0xEDE5D8,
  creamDark: 0xD6CDC0,
  white: 0xFDFDFD,
  shoeSole: 0xF5F5F5,
  eyeSclera: 0xFFFFFF,
  eyeIrisBrown: 0x3E1E12,
  eyePupil: 0x180A05,
  blush: 0xFF6584,
  maleHair: 0x221814,
  capBlack: 0x1A1A1A,
  glassesFrame: 0x111111,
  glassesLens: 0x2A2A2A,
  femaleHair: 0xF2C95C,
  mouthPink: 0xC84B60,
  aglet: 0xD0D0D0
};

export function createMaterials(THREE) {
  return {
    skin: new THREE.MeshStandardMaterial({ color: COLORS.skin, roughness: 0.6, metalness: 0.05 }),
    maroon: new THREE.MeshStandardMaterial({ color: COLORS.maroon, roughness: 0.65, metalness: 0.0 }),
    maroonDark: new THREE.MeshStandardMaterial({ color: COLORS.maroonDark, roughness: 0.7, metalness: 0.0 }),
    cream: new THREE.MeshStandardMaterial({ color: COLORS.cream, roughness: 0.7, metalness: 0.0 }),
    creamDark: new THREE.MeshStandardMaterial({ color: COLORS.creamDark, roughness: 0.75, metalness: 0.0 }),
    white: new THREE.MeshStandardMaterial({ color: COLORS.white, roughness: 0.5, metalness: 0.0 }),
    eyeWhite: new THREE.MeshStandardMaterial({ color: COLORS.eyeSclera, roughness: 0.2, metalness: 0.0 }),
    eyeIris: new THREE.MeshStandardMaterial({ color: COLORS.eyeIrisBrown, roughness: 0.15, metalness: 0.1 }),
    eyePupil: new THREE.MeshStandardMaterial({ color: COLORS.eyePupil, roughness: 0.1, metalness: 0.0 }),
    eyeHighlight: new THREE.MeshBasicMaterial({ color: 0xFFFFFF }),
    blush: new THREE.MeshBasicMaterial({ color: COLORS.blush, transparent: true, opacity: 0.55, depthWrite: false }),
    mouth: new THREE.MeshBasicMaterial({ color: COLORS.mouthPink }),
    maleHair: new THREE.MeshStandardMaterial({ color: COLORS.maleHair, roughness: 0.5, metalness: 0.05 }),
    cap: new THREE.MeshStandardMaterial({ color: COLORS.capBlack, roughness: 0.6, metalness: 0.1 }),
    sunglasses: new THREE.MeshStandardMaterial({ color: COLORS.glassesFrame, roughness: 0.2, metalness: 0.8 }),
    sunglassesLens: new THREE.MeshStandardMaterial({ color: COLORS.glassesLens, roughness: 0.1, metalness: 0.9, transparent: true, opacity: 0.85 }),
    femaleHair: new THREE.MeshStandardMaterial({ color: COLORS.femaleHair, roughness: 0.5, metalness: 0.05 }),
    aglet: new THREE.MeshStandardMaterial({ color: COLORS.aglet, roughness: 0.3, metalness: 0.8 }),
    shoeSole: new THREE.MeshStandardMaterial({ color: COLORS.shoeSole, roughness: 0.8, metalness: 0.0 })
  };
}

export function buildEye(materials, isGirl = false, THREE) {
  const eyeGroup = new THREE.Group();
  
  const scleraGeo = new THREE.SphereGeometry(0.16, 24, 20);
  scleraGeo.scale(1.0, 1.25, 0.4);
  const sclera = new THREE.Mesh(scleraGeo, materials.eyeWhite);
  eyeGroup.add(sclera);

  const irisGeo = new THREE.SphereGeometry(0.12, 20, 16);
  irisGeo.scale(0.95, 1.15, 0.2);
  const iris = new THREE.Mesh(irisGeo, materials.eyeIris);
  iris.position.set(0, 0, 0.045);
  eyeGroup.add(iris);

  const pupilGeo = new THREE.SphereGeometry(0.065, 16, 12);
  pupilGeo.scale(0.9, 1.1, 0.15);
  const pupil = new THREE.Mesh(pupilGeo, materials.eyePupil);
  pupil.position.set(0, 0, 0.06);
  eyeGroup.add(pupil);

  const hlMainGeo = new THREE.SphereGeometry(0.038, 12, 10);
  hlMainGeo.scale(1.0, 1.0, 0.2);
  const hlMain = new THREE.Mesh(hlMainGeo, materials.eyeHighlight);
  hlMain.position.set(0.045, 0.055, 0.075);
  eyeGroup.add(hlMain);

  const hlSubGeo = new THREE.SphereGeometry(0.018, 10, 8);
  hlSubGeo.scale(1.0, 1.0, 0.2);
  const hlSub = new THREE.Mesh(hlSubGeo, materials.eyeHighlight);
  hlSub.position.set(-0.04, -0.04, 0.075);
  eyeGroup.add(hlSub);

  if (isGirl) {
    const lashCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.14, 0.13, 0.04),
      new THREE.Vector3(0.0, 0.21, 0.05),
      new THREE.Vector3(0.15, 0.17, 0.06),
      new THREE.Vector3(0.22, 0.22, 0.05)
    ]);
    const lashGeo = new THREE.TubeGeometry(lashCurve, 12, 0.014, 6, false);
    const lash = new THREE.Mesh(lashGeo, materials.cap);
    eyeGroup.add(lash);
  }

  const lidGeo = new THREE.SphereGeometry(0.17, 24, 12, 0, Math.PI * 2, 0, Math.PI * 0.5);
  lidGeo.scale(1.02, 1.28, 0.45);
  const eyelid = new THREE.Mesh(lidGeo, materials.skin);
  eyelid.position.set(0, 0.05, 0.01);
  eyelid.rotation.x = -Math.PI * 0.5;
  eyelid.name = 'eyelid';
  eyeGroup.add(eyelid);

  return eyeGroup;
}

export function buildSneaker(materials, THREE) {
  const shoeGroup = new THREE.Group();

  const soleGeo = new THREE.BoxGeometry(0.28, 0.10, 0.52);
  const sole = new THREE.Mesh(soleGeo, materials.shoeSole);
  sole.position.set(0, 0.05, 0.04);
  shoeGroup.add(sole);

  const upperGeo = new THREE.BoxGeometry(0.26, 0.18, 0.48);
  const upper = new THREE.Mesh(upperGeo, materials.maroon);
  upper.position.set(0, 0.16, 0.03);
  shoeGroup.add(upper);

  const toeGeo = new THREE.CylinderGeometry(0.13, 0.135, 0.14, 16, 1, false, -Math.PI*0.5, Math.PI);
  toeGeo.scale(1.0, 1.0, 0.85);
  toeGeo.rotateZ(Math.PI * 0.5);
  const toeCap = new THREE.Mesh(toeGeo, materials.white);
  toeCap.position.set(0, 0.13, 0.22);
  shoeGroup.add(toeCap);

  for (let i = 0; i < 3; i++) {
    const laceGeo = new THREE.BoxGeometry(0.18, 0.02, 0.04);
    const lace = new THREE.Mesh(laceGeo, materials.white);
    lace.position.set(0, 0.25, 0.02 + i * 0.07);
    lace.rotation.x = -0.2;
    shoeGroup.add(lace);
  }

  const stripeGeo = new THREE.BoxGeometry(0.27, 0.02, 0.32);
  const stripe = new THREE.Mesh(stripeGeo, materials.white);
  stripe.position.set(0, 0.15, -0.01);
  shoeGroup.add(stripe);

  return shoeGroup;
}

export function buildMohan(THREE) {
  const materials = createMaterials(THREE);
  const root = new THREE.Group();
  root.name = 'Mohan';

  const hips = new THREE.Group();
  hips.name = 'Hips';
  hips.position.set(0, 1.15, 0);
  root.add(hips);

  const pelvisGeo = new THREE.CylinderGeometry(0.28, 0.26, 0.25, 20);
  const pelvis = new THREE.Mesh(pelvisGeo, materials.cream);
  hips.add(pelvis);

  const spine = new THREE.Group();
  spine.name = 'Spine';
  spine.position.set(0, 0.18, 0);
  hips.add(spine);

  const chest = new THREE.Group();
  chest.name = 'Chest';
  chest.position.set(0, 0.32, 0);
  spine.add(chest);

  const hoodieGeo = new THREE.CylinderGeometry(0.38, 0.35, 0.72, 24);
  hoodieGeo.scale(1.15, 1.0, 0.9);
  const hoodie = new THREE.Mesh(hoodieGeo, materials.maroon);
  hoodie.position.set(0, -0.08, 0);
  chest.add(hoodie);

  const pocketGeo = new THREE.BoxGeometry(0.38, 0.22, 0.12);
  const pocket = new THREE.Mesh(pocketGeo, materials.maroonDark);
  pocket.position.set(0, -0.16, 0.30);
  pocket.rotation.x = -0.1;
  chest.add(pocket);

  for (const side of [-1, 1]) {
    const stringGeo = new THREE.CylinderGeometry(0.012, 0.012, 0.35, 8);
    const cord = new THREE.Mesh(stringGeo, materials.white);
    cord.position.set(side * 0.11, -0.09, 0.34);
    chest.add(cord);

    const agletGeo = new THREE.CylinderGeometry(0.015, 0.015, 0.05, 8);
    const aglet = new THREE.Mesh(agletGeo, materials.aglet);
    aglet.position.set(side * 0.11, -0.27, 0.34);
    chest.add(aglet);
  }

  const hoodGeo = new THREE.TorusGeometry(0.32, 0.12, 12, 24, Math.PI * 1.5);
  hoodGeo.rotateX(Math.PI * 0.5);
  hoodGeo.rotateZ(Math.PI * 0.25);
  const hood = new THREE.Mesh(hoodGeo, materials.maroonDark);
  hood.position.set(0, 0.22, -0.08);
  chest.add(hood);

  const neck = new THREE.Group();
  neck.name = 'Neck';
  neck.position.set(0, 0.35, 0);
  chest.add(neck);

  const neckMeshGeo = new THREE.CylinderGeometry(0.14, 0.16, 0.18, 16);
  const neckMesh = new THREE.Mesh(neckMeshGeo, materials.skin);
  neck.add(neckMesh);

  const head = new THREE.Group();
  head.name = 'Head';
  head.position.set(0, 0.42, 0);
  neck.add(head);

  const headGeo = new THREE.SphereGeometry(0.62, 32, 28);
  headGeo.scale(1.08, 0.98, 1.0);
  const headMesh = new THREE.Mesh(headGeo, materials.skin);
  head.add(headMesh);

  for (const side of [-1, 1]) {
    const earGeo = new THREE.SphereGeometry(0.12, 16, 12);
    earGeo.scale(0.5, 1.0, 0.8);
    const ear = new THREE.Mesh(earGeo, materials.skin);
    ear.position.set(side * 0.65, -0.04, -0.08);
    head.add(ear);
  }

  const noseGeo = new THREE.SphereGeometry(0.042, 12, 10);
  const nose = new THREE.Mesh(noseGeo, materials.skin);
  nose.position.set(0, -0.04, 0.62);
  head.add(nose);

  const leftEye = buildEye(materials, false, THREE);
  leftEye.name = 'LeftEye';
  leftEye.position.set(0.24, 0.04, 0.55);
  leftEye.rotation.y = 0.22;
  head.add(leftEye);

  const rightEye = buildEye(materials, false, THREE);
  rightEye.name = 'RightEye';
  rightEye.position.set(-0.24, 0.04, 0.55);
  rightEye.rotation.y = -0.22;
  head.add(rightEye);

  for (const side of [-1, 1]) {
    const browGeo = new THREE.BoxGeometry(0.18, 0.032, 0.02);
    const brow = new THREE.Mesh(browGeo, materials.maleHair);
    brow.position.set(side * 0.24, 0.25, 0.57);
    brow.rotation.z = side * -0.15;
    brow.rotation.y = side * 0.2;
    head.add(brow);
  }

  const mouthGeo = new THREE.TorusGeometry(0.08, 0.02, 8, 16, Math.PI);
  mouthGeo.rotateX(Math.PI);
  const mouth = new THREE.Mesh(mouthGeo, materials.mouth);
  mouth.name = 'Mouth';
  mouth.position.set(0, -0.22, 0.57);
  head.add(mouth);

  for (const side of [-1, 1]) {
    const blushGeo = new THREE.CircleGeometry(0.11, 20);
    const blushMesh = new THREE.Mesh(blushGeo, materials.blush);
    blushMesh.position.set(side * 0.38, -0.14, 0.51);
    blushMesh.rotation.y = side * 0.6;
    head.add(blushMesh);
  }

  const hairBangsGroup = new THREE.Group();
  for (let i = -3; i <= 3; i++) {
    const tuftGeo = new THREE.ConeGeometry(0.10, 0.26, 8);
    tuftGeo.rotateZ(Math.PI + (i * 0.12));
    const tuft = new THREE.Mesh(tuftGeo, materials.maleHair);
    tuft.position.set(i * 0.12, 0.34, 0.52 - Math.abs(i) * 0.04);
    hairBangsGroup.add(tuft);
  }
  head.add(hairBangsGroup);

  const capGroup = new THREE.Group();
  capGroup.position.set(0, 0.22, -0.05);

  const capDomeGeo = new THREE.SphereGeometry(0.66, 28, 20, 0, Math.PI * 2, 0, Math.PI * 0.55);
  const capDome = new THREE.Mesh(capDomeGeo, materials.cap);
  capGroup.add(capDome);

  const visorGeo = new THREE.CylinderGeometry(0.72, 0.72, 0.035, 24, 1, false, -Math.PI * 0.38, Math.PI * 0.76);
  visorGeo.rotateY(Math.PI * 0.5);
  const visor = new THREE.Mesh(visorGeo, materials.cap);
  visor.position.set(0, 0.02, 0.22);
  visor.rotation.x = -0.15;
  capGroup.add(visor);

  const btnGeo = new THREE.SphereGeometry(0.04, 12, 8);
  const capBtn = new THREE.Mesh(btnGeo, materials.cap);
  capBtn.position.set(0, 0.68, 0);
  capGroup.add(capBtn);

  const glassesGroup = new THREE.Group();
  glassesGroup.position.set(0, 0.25, 0.55);
  glassesGroup.rotation.x = -0.28;

  for (const side of [-1, 1]) {
    const lensGeo = new THREE.BoxGeometry(0.24, 0.14, 0.02);
    const lens = new THREE.Mesh(lensGeo, materials.sunglassesLens);
    lens.position.set(side * 0.16, 0, 0);
    glassesGroup.add(lens);

    const frameGeo = new THREE.BoxGeometry(0.26, 0.16, 0.025);
    const frame = new THREE.Mesh(frameGeo, materials.sunglasses);
    frame.position.set(side * 0.16, 0, -0.005);
    glassesGroup.add(frame);
  }
  const bridgeGeo = new THREE.BoxGeometry(0.12, 0.03, 0.025);
  const bridge = new THREE.Mesh(bridgeGeo, materials.sunglasses);
  bridge.position.set(0, 0.03, 0);
  glassesGroup.add(bridge);

  capGroup.add(glassesGroup);
  head.add(capGroup);

  for (const side of [-1, 1]) {
    const isLeft = side === 1;
    const prefix = isLeft ? 'Left' : 'Right';

    const shoulder = new THREE.Group();
    shoulder.name = `${prefix}Shoulder`;
    shoulder.position.set(side * 0.40, 0.15, 0);
    chest.add(shoulder);

    const upperArm = new THREE.Group();
    upperArm.name = `${prefix}UpperArm`;
    upperArm.position.set(side * 0.08, -0.06, 0);
    shoulder.add(upperArm);

    const upperArmMeshGeo = new THREE.CylinderGeometry(0.12, 0.11, 0.38, 16);
    const upperArmMesh = new THREE.Mesh(upperArmMeshGeo, materials.maroon);
    upperArmMesh.position.set(0, -0.16, 0);
    upperArm.add(upperArmMesh);

    const forearm = new THREE.Group();
    forearm.name = `${prefix}Forearm`;
    forearm.position.set(0, -0.34, 0);
    upperArm.add(forearm);

    const forearmMeshGeo = new THREE.CylinderGeometry(0.105, 0.095, 0.34, 16);
    const forearmMesh = new THREE.Mesh(forearmMeshGeo, materials.maroon);
    forearmMesh.position.set(0, -0.15, 0);
    forearm.add(forearmMesh);

    const cuffGeo = new THREE.CylinderGeometry(0.10, 0.10, 0.06, 16);
    const cuff = new THREE.Mesh(cuffGeo, materials.cream);
    cuff.position.set(0, -0.32, 0);
    forearm.add(cuff);

    const hand = new THREE.Group();
    hand.name = `${prefix}Hand`;
    hand.position.set(0, -0.38, 0);
    forearm.add(hand);

    const handGeo = new THREE.SphereGeometry(0.10, 16, 12);
    handGeo.scale(1.0, 1.2, 0.7);
    const handMesh = new THREE.Mesh(handGeo, materials.skin);
    handMesh.position.set(0, -0.06, 0);
    hand.add(handMesh);

    const thumbGeo = new THREE.SphereGeometry(0.045, 10, 8);
    thumbGeo.scale(0.8, 1.4, 0.8);
    const thumb = new THREE.Mesh(thumbGeo, materials.skin);
    thumb.position.set(side * -0.06, -0.04, 0.05);
    thumb.rotation.z = side * 0.4;
    hand.add(thumb);
  }

  for (const side of [-1, 1]) {
    const isLeft = side === 1;
    const prefix = isLeft ? 'Left' : 'Right';

    const thigh = new THREE.Group();
    thigh.name = `${prefix}Thigh`;
    thigh.position.set(side * 0.19, -0.12, 0);
    hips.add(thigh);

    const thighMeshGeo = new THREE.CylinderGeometry(0.15, 0.13, 0.48, 16);
    const thighMesh = new THREE.Mesh(thighMeshGeo, materials.cream);
    thighMesh.position.set(0, -0.22, 0);
    thigh.add(thighMesh);

    const shin = new THREE.Group();
    shin.name = `${prefix}Shin`;
    shin.position.set(0, -0.46, 0);
    thigh.add(shin);

    const shinMeshGeo = new THREE.CylinderGeometry(0.13, 0.115, 0.44, 16);
    const shinMesh = new THREE.Mesh(shinMeshGeo, materials.cream);
    shinMesh.position.set(0, -0.20, 0);
    shin.add(shinMesh);

    const foot = new THREE.Group();
    foot.name = `${prefix}Foot`;
    foot.position.set(0, -0.42, 0);
    shin.add(foot);

    const sneaker = buildSneaker(materials, THREE);
    foot.add(sneaker);
  }

  return root;
}

export function buildCompanion(THREE) {
  const materials = createMaterials(THREE);
  const root = new THREE.Group();
  root.name = 'Companion';

  const hips = new THREE.Group();
  hips.name = 'Hips';
  hips.position.set(0, 1.12, 0);
  root.add(hips);

  const pelvisGeo = new THREE.CylinderGeometry(0.26, 0.24, 0.24, 20);
  const pelvis = new THREE.Mesh(pelvisGeo, materials.cream);
  hips.add(pelvis);

  const spine = new THREE.Group();
  spine.name = 'Spine';
  spine.position.set(0, 0.17, 0);
  hips.add(spine);

  const chest = new THREE.Group();
  chest.name = 'Chest';
  chest.position.set(0, 0.30, 0);
  spine.add(chest);

  const hoodieGeo = new THREE.CylinderGeometry(0.36, 0.33, 0.68, 24);
  hoodieGeo.scale(1.12, 1.0, 0.88);
  const hoodie = new THREE.Mesh(hoodieGeo, materials.maroon);
  hoodie.position.set(0, -0.08, 0);
  chest.add(hoodie);

  const pocketGeo = new THREE.BoxGeometry(0.35, 0.20, 0.11);
  const pocket = new THREE.Mesh(pocketGeo, materials.maroonDark);
  pocket.position.set(0, -0.15, 0.28);
  pocket.rotation.x = -0.1;
  chest.add(pocket);

  for (const side of [-1, 1]) {
    const stringGeo = new THREE.CylinderGeometry(0.011, 0.011, 0.34, 8);
    const cord = new THREE.Mesh(stringGeo, materials.white);
    cord.position.set(side * 0.10, -0.09, 0.32);
    chest.add(cord);

    const agletGeo = new THREE.CylinderGeometry(0.014, 0.014, 0.048, 8);
    const aglet = new THREE.Mesh(agletGeo, materials.aglet);
    aglet.position.set(side * 0.10, -0.26, 0.32);
    chest.add(aglet);
  }

  const hoodGeo = new THREE.TorusGeometry(0.30, 0.11, 12, 24, Math.PI * 1.5);
  hoodGeo.rotateX(Math.PI * 0.5);
  hoodGeo.rotateZ(Math.PI * 0.25);
  const hood = new THREE.Mesh(hoodGeo, materials.maroonDark);
  hood.position.set(0, 0.21, -0.08);
  chest.add(hood);

  const neck = new THREE.Group();
  neck.name = 'Neck';
  neck.position.set(0, 0.34, 0);
  chest.add(neck);

  const neckMeshGeo = new THREE.CylinderGeometry(0.13, 0.15, 0.17, 16);
  const neckMesh = new THREE.Mesh(neckMeshGeo, materials.skin);
  neck.add(neckMesh);

  const head = new THREE.Group();
  head.name = 'Head';
  head.position.set(0, 0.40, 0);
  neck.add(head);

  const headGeo = new THREE.SphereGeometry(0.60, 32, 28);
  headGeo.scale(1.06, 0.98, 1.0);
  const headMesh = new THREE.Mesh(headGeo, materials.skin);
  head.add(headMesh);

  for (const side of [-1, 1]) {
    const earGeo = new THREE.SphereGeometry(0.11, 16, 12);
    earGeo.scale(0.5, 1.0, 0.8);
    const ear = new THREE.Mesh(earGeo, materials.skin);
    ear.position.set(side * 0.63, -0.04, -0.08);
    head.add(ear);
  }

  const noseGeo = new THREE.SphereGeometry(0.038, 12, 10);
  const nose = new THREE.Mesh(noseGeo, materials.skin);
  nose.position.set(0, -0.04, 0.60);
  head.add(nose);

  const leftEye = buildEye(materials, true, THREE);
  leftEye.name = 'LeftEye';
  leftEye.position.set(0.23, 0.04, 0.54);
  leftEye.rotation.y = 0.22;
  head.add(leftEye);

  const rightEye = buildEye(materials, true, THREE);
  rightEye.name = 'RightEye';
  rightEye.position.set(-0.23, 0.04, 0.54);
  rightEye.rotation.y = -0.22;
  head.add(rightEye);

  for (const side of [-1, 1]) {
    const browGeo = new THREE.BoxGeometry(0.17, 0.026, 0.02);
    const brow = new THREE.Mesh(browGeo, materials.femaleHair);
    brow.position.set(side * 0.23, 0.25, 0.56);
    brow.rotation.z = side * -0.12;
    brow.rotation.y = side * 0.2;
    head.add(brow);
  }

  const mouthGeo = new THREE.TorusGeometry(0.085, 0.02, 8, 16, Math.PI);
  mouthGeo.rotateX(Math.PI);
  const mouth = new THREE.Mesh(mouthGeo, materials.mouth);
  mouth.name = 'Mouth';
  mouth.position.set(0, -0.21, 0.56);
  head.add(mouth);

  for (const side of [-1, 1]) {
    const blushGeo = new THREE.CircleGeometry(0.13, 20);
    const blushMesh = new THREE.Mesh(blushGeo, materials.blush);
    blushMesh.position.set(side * 0.36, -0.13, 0.50);
    blushMesh.rotation.y = side * 0.58;
    head.add(blushMesh);
  }

  const hairGroup = new THREE.Group();
  hairGroup.name = 'BlondeHair';

  const crownGeo = new THREE.SphereGeometry(0.67, 28, 22);
  crownGeo.scale(1.08, 1.05, 1.05);
  const crown = new THREE.Mesh(crownGeo, materials.femaleHair);
  crown.position.set(0, 0.06, -0.10);
  hairGroup.add(crown);

  for (let i = -3; i <= 3; i++) {
    const bangGeo = new THREE.ConeGeometry(0.12, 0.35, 10);
    bangGeo.rotateZ(Math.PI + (i * 0.15));
    const bang = new THREE.Mesh(bangGeo, materials.femaleHair);
    bang.position.set(i * 0.13, 0.38, 0.50 - Math.abs(i) * 0.04);
    hairGroup.add(bang);
  }

  for (const side of [-1, 1]) {
    const sideCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(side * 0.55, 0.28, 0.20),
      new THREE.Vector3(side * 0.62, 0.00, 0.32),
      new THREE.Vector3(side * 0.58, -0.32, 0.28),
      new THREE.Vector3(side * 0.50, -0.55, 0.20)
    ]);
    const sideGeo = new THREE.TubeGeometry(sideCurve, 16, 0.075, 8, false);
    const sideLock = new THREE.Mesh(sideGeo, materials.femaleHair);
    hairGroup.add(sideLock);
  }

  for (let b = -2; b <= 2; b++) {
    const backCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(b * 0.18, 0.10, -0.55),
      new THREE.Vector3(b * 0.22, -0.25, -0.50),
      new THREE.Vector3(b * 0.20, -0.65, -0.35)
    ]);
    const backGeo = new THREE.TubeGeometry(backCurve, 12, 0.09, 8, false);
    const backLock = new THREE.Mesh(backGeo, materials.femaleHair);
    hairGroup.add(backLock);
  }

  head.add(hairGroup);

  for (const side of [-1, 1]) {
    const isLeft = side === 1;
    const prefix = isLeft ? 'Left' : 'Right';

    const shoulder = new THREE.Group();
    shoulder.name = `${prefix}Shoulder`;
    shoulder.position.set(side * 0.38, 0.14, 0);
    chest.add(shoulder);

    const upperArm = new THREE.Group();
    upperArm.name = `${prefix}UpperArm`;
    upperArm.position.set(side * 0.07, -0.06, 0);
    shoulder.add(upperArm);

    const upperArmMeshGeo = new THREE.CylinderGeometry(0.11, 0.10, 0.36, 16);
    const upperArmMesh = new THREE.Mesh(upperArmMeshGeo, materials.maroon);
    upperArmMesh.position.set(0, -0.15, 0);
    upperArm.add(upperArmMesh);

    const forearm = new THREE.Group();
    forearm.name = `${prefix}Forearm`;
    forearm.position.set(0, -0.32, 0);
    upperArm.add(forearm);

    const forearmMeshGeo = new THREE.CylinderGeometry(0.095, 0.088, 0.32, 16);
    const forearmMesh = new THREE.Mesh(forearmMeshGeo, materials.maroon);
    forearmMesh.position.set(0, -0.14, 0);
    forearm.add(forearmMesh);

    const cuffGeo = new THREE.CylinderGeometry(0.092, 0.092, 0.055, 16);
    const cuff = new THREE.Mesh(cuffGeo, materials.cream);
    cuff.position.set(0, -0.30, 0);
    forearm.add(cuff);

    const hand = new THREE.Group();
    hand.name = `${prefix}Hand`;
    hand.position.set(0, -0.36, 0);
    forearm.add(hand);

    const handGeo = new THREE.SphereGeometry(0.092, 16, 12);
    handGeo.scale(1.0, 1.2, 0.68);
    const handMesh = new THREE.Mesh(handGeo, materials.skin);
    handMesh.position.set(0, -0.055, 0);
    hand.add(handMesh);

    const thumbGeo = new THREE.SphereGeometry(0.042, 10, 8);
    thumbGeo.scale(0.8, 1.4, 0.8);
    const thumb = new THREE.Mesh(thumbGeo, materials.skin);
    thumb.position.set(side * -0.055, -0.038, 0.045);
    thumb.rotation.z = side * 0.4;
    hand.add(thumb);
  }

  for (const side of [-1, 1]) {
    const isLeft = side === 1;
    const prefix = isLeft ? 'Left' : 'Right';

    const thigh = new THREE.Group();
    thigh.name = `${prefix}Thigh`;
    thigh.position.set(side * 0.18, -0.11, 0);
    hips.add(thigh);

    const thighMeshGeo = new THREE.CylinderGeometry(0.14, 0.12, 0.46, 16);
    const thighMesh = new THREE.Mesh(thighMeshGeo, materials.cream);
    thighMesh.position.set(0, -0.21, 0);
    thigh.add(thighMesh);

    const shin = new THREE.Group();
    shin.name = `${prefix}Shin`;
    shin.position.set(0, -0.44, 0);
    thigh.add(shin);

    const shinMeshGeo = new THREE.CylinderGeometry(0.12, 0.108, 0.42, 16);
    const shinMesh = new THREE.Mesh(shinMeshGeo, materials.cream);
    shinMesh.position.set(0, -0.19, 0);
    shin.add(shinMesh);

    const foot = new THREE.Group();
    foot.name = `${prefix}Foot`;
    foot.position.set(0, -0.40, 0);
    shin.add(foot);

    const sneaker = buildSneaker(materials, THREE);
    foot.add(sneaker);
  }

  return root;
}

// Animation Controller
export class DuoCharacterController {
  constructor(model, isGirl = false, THREE) {
    this.THREE = THREE;
    this.model = model;
    this.isGirl = isGirl;
    this.name = isGirl ? 'Companion' : 'Mohan';

    this.nodes = {
      hips: model.getObjectByName('Hips'),
      spine: model.getObjectByName('Spine'),
      chest: model.getObjectByName('Chest'),
      neck: model.getObjectByName('Neck'),
      head: model.getObjectByName('Head'),
      mouth: model.getObjectByName('Mouth'),
      leftEye: model.getObjectByName('LeftEye'),
      rightEye: model.getObjectByName('RightEye'),
      leftEyelid: model.getObjectByName('LeftEye')?.getObjectByName('eyelid'),
      rightEyelid: model.getObjectByName('RightEye')?.getObjectByName('eyelid'),
      leftShoulder: model.getObjectByName('LeftShoulder'),
      rightShoulder: model.getObjectByName('RightShoulder'),
      leftUpperArm: model.getObjectByName('LeftUpperArm'),
      rightUpperArm: model.getObjectByName('RightUpperArm'),
      leftForearm: model.getObjectByName('LeftForearm'),
      rightForearm: model.getObjectByName('RightForearm'),
      leftHand: model.getObjectByName('LeftHand'),
      rightHand: model.getObjectByName('RightHand'),
      leftThigh: model.getObjectByName('LeftThigh'),
      rightThigh: model.getObjectByName('RightThigh'),
      leftShin: model.getObjectByName('LeftShin'),
      rightShin: model.getObjectByName('RightShin'),
      leftFoot: model.getObjectByName('LeftFoot'),
      rightFoot: model.getObjectByName('RightFoot')
    };

    this.blushMeshes = [];
    model.traverse((child) => {
      if (child.material && child.material.opacity !== undefined && child.material.transparent) {
        this.blushMeshes.push(child);
      }
    });

    this.currentAction = 'idle';
    this.actionProgress = 0;
    this.isTalking = false;
    this.talkTimer = 0;
    this.isSmiling = false;
    this.isBlushing = false;
    this.blushAmount = 0.55;

    this.blinkTimer = 2.0 + Math.random() * 2.5;
    this.blinkProgress = 0;
    this.isBlinking = false;

    this.lookTarget = null;
    this.lookWeight = 0;

    this.baseHipY = this.nodes.hips ? this.nodes.hips.position.y : 1.15;
  }

  playAction(name) {
    this.currentAction = name;
    this.actionProgress = 0;
    if (name === 'blush') {
      this.isBlushing = true;
      this.isSmiling = true;
      setTimeout(() => {
        this.isBlushing = false;
        this.isSmiling = false;
        if (this.currentAction === 'blush') this.currentAction = 'idle';
      }, 3000);
    } else if (name === 'smile') {
      this.isSmiling = true;
      setTimeout(() => {
        this.isSmiling = false;
        if (this.currentAction === 'smile') this.currentAction = 'idle';
      }, 2500);
    }
  }

  setTalking(isTalking) {
    this.isTalking = isTalking;
    if (!isTalking && this.nodes.mouth) {
      this.nodes.mouth.scale.set(1, 1, 1);
    }
  }

  setLookAt(targetVec3, weight = 1.0) {
    this.lookTarget = targetVec3;
    this.lookWeight = weight;
  }

  update(delta) {
    this.actionProgress += delta;

    // 1. Blinking
    this.blinkTimer -= delta;
    if (this.blinkTimer <= 0 && !this.isBlinking) {
      this.isBlinking = true;
      this.blinkProgress = 0;
      this.blinkTimer = 2.5 + Math.random() * 3.5;
    }

    if (this.isBlinking) {
      this.blinkProgress += delta * 6.0;
      let eyelidRot = -Math.PI * 0.5;
      if (this.blinkProgress < 0.5) {
        eyelidRot = this.THREE.MathUtils.lerp(-Math.PI * 0.5, 0, this.blinkProgress * 2);
      } else if (this.blinkProgress < 1.0) {
        eyelidRot = this.THREE.MathUtils.lerp(0, -Math.PI * 0.5, (this.blinkProgress - 0.5) * 2);
      } else {
        this.isBlinking = false;
        eyelidRot = -Math.PI * 0.5;
      }
      if (this.nodes.leftEyelid) this.nodes.leftEyelid.rotation.x = eyelidRot;
      if (this.nodes.rightEyelid) this.nodes.rightEyelid.rotation.x = eyelidRot;
    }

    // 2. Lip Sync & Talking
    if (this.isTalking) {
      this.talkTimer += delta * 12.0;
      const talkScale = 1.0 + Math.abs(Math.sin(this.talkTimer)) * 0.55;
      if (this.nodes.mouth) {
        this.nodes.mouth.scale.set(talkScale, talkScale * 1.3, 1.0);
      }
      if (this.nodes.head) {
        this.nodes.head.rotation.z += Math.sin(this.talkTimer * 0.5) * 0.008;
      }
    } else if (this.isSmiling) {
      if (this.nodes.mouth) {
        this.nodes.mouth.scale.set(1.3, 1.25, 1.0);
      }
    }

    // 3. Blush
    const targetBlush = this.isBlushing ? 0.95 : (this.currentAction === 'hug' ? 0.9 : 0.55);
    this.blushAmount = this.THREE.MathUtils.lerp(this.blushAmount, targetBlush, delta * 3.0);
    this.blushMeshes.forEach(m => {
      m.material.opacity = this.blushAmount;
    });

    // 4. Action poses
    switch (this.currentAction) {
      case 'idle':
        this.animateIdle(delta);
        break;
      case 'walk':
        this.animateWalk(delta, 1.0);
        break;
      case 'sit':
        this.animateSit(delta);
        break;
      case 'hug':
        this.animateHug(delta);
        break;
      case 'hold_hands':
        this.animateHoldHands(delta);
        break;
      case 'couple_walk':
        this.animateCoupleWalk(delta);
        break;
      case 'look_at_each_other':
        this.animateLookPartner(delta);
        break;
      default:
        this.animateIdle(delta);
    }

    // 5. Look-at target
    if (this.lookTarget && this.nodes.head && this.currentAction !== 'sit' && this.currentAction !== 'hug') {
      const worldPos = new this.THREE.Vector3();
      this.model.getWorldPosition(worldPos);
      const dx = this.lookTarget.x - worldPos.x;
      const dz = this.lookTarget.z - worldPos.z;
      const angle = Math.atan2(dx, dz);
      const clampedAngle = this.THREE.MathUtils.clamp(angle, -0.7, 0.7);
      this.nodes.head.rotation.y = this.THREE.MathUtils.lerp(this.nodes.head.rotation.y, clampedAngle, delta * 4.0);
    }
  }

  animateIdle(delta) {
    const t = this.actionProgress * 2.2;
    if (this.nodes.chest) {
      this.nodes.chest.position.y = 0.32 + Math.sin(t) * 0.012;
      this.nodes.chest.rotation.x = Math.sin(t) * 0.015;
    }
    if (this.nodes.head) {
      this.nodes.head.rotation.z = Math.sin(t * 0.6) * 0.02;
      this.nodes.head.rotation.x = Math.sin(t * 0.9) * 0.01;
    }
    if (this.nodes.leftUpperArm) {
      this.nodes.leftUpperArm.rotation.z = 0.1 + Math.sin(t) * 0.02;
      this.nodes.leftUpperArm.rotation.x = 0;
    }
    if (this.nodes.rightUpperArm) {
      this.nodes.rightUpperArm.rotation.z = -0.1 - Math.sin(t) * 0.02;
      this.nodes.rightUpperArm.rotation.x = 0;
    }
    if (this.nodes.hips) {
      this.nodes.hips.position.y = this.THREE.MathUtils.lerp(this.nodes.hips.position.y, this.baseHipY, delta * 5.0);
      this.nodes.hips.position.z = 0;
    }
    if (this.nodes.leftThigh) this.nodes.leftThigh.rotation.x = 0;
    if (this.nodes.rightThigh) this.nodes.rightThigh.rotation.x = 0;
    if (this.nodes.leftShin) this.nodes.leftShin.rotation.x = 0;
    if (this.nodes.rightShin) this.nodes.rightShin.rotation.x = 0;
  }

  animateWalk(delta, speed = 1.0) {
    const t = this.actionProgress * 5.5 * speed;
    const legAngle = Math.sin(t) * 0.48;
    const armAngle = -legAngle * 0.75;

    if (this.nodes.hips) {
      this.nodes.hips.position.y = this.baseHipY + Math.abs(Math.sin(t)) * 0.035;
      this.nodes.hips.rotation.y = Math.sin(t) * 0.06;
    }

    if (this.nodes.leftThigh) this.nodes.leftThigh.rotation.x = legAngle;
    if (this.nodes.rightThigh) this.nodes.rightThigh.rotation.x = -legAngle;

    if (this.nodes.leftShin) {
      this.nodes.leftShin.rotation.x = legAngle < 0 ? Math.sin(t) * 0.35 : 0;
    }
    if (this.nodes.rightShin) {
      this.nodes.rightShin.rotation.x = -legAngle < 0 ? -Math.sin(t) * 0.35 : 0;
    }

    if (this.nodes.leftUpperArm) {
      this.nodes.leftUpperArm.rotation.x = armAngle;
      this.nodes.leftUpperArm.rotation.z = 0.12;
    }
    if (this.nodes.rightUpperArm) {
      this.nodes.rightUpperArm.rotation.x = -armAngle;
      this.nodes.rightUpperArm.rotation.z = -0.12;
    }
  }

  animateSit(delta) {
    const sitSpeed = delta * 4.0;
    if (this.nodes.hips) {
      this.nodes.hips.position.y = this.THREE.MathUtils.lerp(this.nodes.hips.position.y, 0.60, sitSpeed);
      this.nodes.hips.position.z = this.THREE.MathUtils.lerp(this.nodes.hips.position.z, -0.22, sitSpeed);
    }
    if (this.nodes.leftThigh) this.nodes.leftThigh.rotation.x = this.THREE.MathUtils.lerp(this.nodes.leftThigh.rotation.x, 1.52, sitSpeed);
    if (this.nodes.rightThigh) this.nodes.rightThigh.rotation.x = this.THREE.MathUtils.lerp(this.nodes.rightThigh.rotation.x, 1.52, sitSpeed);
    if (this.nodes.leftShin) this.nodes.leftShin.rotation.x = this.THREE.MathUtils.lerp(this.nodes.leftShin.rotation.x, -1.45, sitSpeed);
    if (this.nodes.rightShin) this.nodes.rightShin.rotation.x = this.THREE.MathUtils.lerp(this.nodes.rightShin.rotation.x, -1.45, sitSpeed);

    if (this.nodes.leftUpperArm) {
      this.nodes.leftUpperArm.rotation.x = this.THREE.MathUtils.lerp(this.nodes.leftUpperArm.rotation.x, 0.45, sitSpeed);
      this.nodes.leftUpperArm.rotation.z = 0.08;
    }
    if (this.nodes.rightUpperArm) {
      this.nodes.rightUpperArm.rotation.x = this.THREE.MathUtils.lerp(this.nodes.rightUpperArm.rotation.x, 0.45, sitSpeed);
      this.nodes.rightUpperArm.rotation.z = -0.08;
    }
    if (this.nodes.head) {
      this.nodes.head.rotation.x = 0.05;
    }
  }

  animateHug(delta) {
    const hugAngle = this.isGirl ? 0.38 : -0.38;
    const blend = delta * 3.5;

    if (this.nodes.chest) {
      this.nodes.chest.rotation.y = this.THREE.MathUtils.lerp(this.nodes.chest.rotation.y, hugAngle, blend);
    }
    if (this.nodes.leftUpperArm) {
      this.nodes.leftUpperArm.rotation.z = this.THREE.MathUtils.lerp(this.nodes.leftUpperArm.rotation.z, 0.65, blend);
      this.nodes.leftUpperArm.rotation.x = this.THREE.MathUtils.lerp(this.nodes.leftUpperArm.rotation.x, 0.3, blend);
    }
    if (this.nodes.rightUpperArm) {
      this.nodes.rightUpperArm.rotation.z = this.THREE.MathUtils.lerp(this.nodes.rightUpperArm.rotation.z, -0.65, blend);
      this.nodes.rightUpperArm.rotation.x = this.THREE.MathUtils.lerp(this.nodes.rightUpperArm.rotation.x, 0.3, blend);
    }
    if (this.nodes.leftForearm) {
      this.nodes.leftForearm.rotation.y = this.THREE.MathUtils.lerp(this.nodes.leftForearm.rotation.y, 0.85, blend);
    }
    if (this.nodes.rightForearm) {
      this.nodes.rightForearm.rotation.y = this.THREE.MathUtils.lerp(this.nodes.rightForearm.rotation.y, -0.85, blend);
    }
    if (this.nodes.head) {
      this.nodes.head.rotation.z = this.THREE.MathUtils.lerp(this.nodes.head.rotation.z, hugAngle * 0.5, blend);
      this.nodes.head.rotation.x = 0.08;
    }
  }

  animateHoldHands(delta) {
    const blend = delta * 4.0;
    const innerArm = this.isGirl ? 'left' : 'right';
    const outerArm = this.isGirl ? 'right' : 'left';
    const innerSign = this.isGirl ? 1 : -1;

    const innerNode = innerArm === 'left' ? this.nodes.leftUpperArm : this.nodes.rightUpperArm;
    const outerNode = outerArm === 'left' ? this.nodes.leftUpperArm : this.nodes.rightUpperArm;

    if (innerNode) {
      innerNode.rotation.z = this.THREE.MathUtils.lerp(innerNode.rotation.z, innerSign * 0.38, blend);
      innerNode.rotation.x = this.THREE.MathUtils.lerp(innerNode.rotation.x, -0.15, blend);
    }
    if (outerNode) {
      outerNode.rotation.z = this.THREE.MathUtils.lerp(outerNode.rotation.z, -innerSign * 0.12, blend);
      outerNode.rotation.x = 0;
    }

    if (this.nodes.head) {
      this.nodes.head.rotation.y = this.THREE.MathUtils.lerp(this.nodes.head.rotation.y, -innerSign * 0.28, blend);
    }
  }

  animateCoupleWalk(delta) {
    const t = this.actionProgress * 5.0;
    const legAngle = Math.sin(t) * 0.40;
    const innerArm = this.isGirl ? 'left' : 'right';
    const outerArm = this.isGirl ? 'right' : 'left';
    const innerSign = this.isGirl ? 1 : -1;

    if (this.nodes.hips) {
      this.nodes.hips.position.y = this.baseHipY + Math.abs(Math.sin(t)) * 0.03;
    }

    if (this.nodes.leftThigh) this.nodes.leftThigh.rotation.x = legAngle;
    if (this.nodes.rightThigh) this.nodes.rightThigh.rotation.x = -legAngle;

    const innerNode = innerArm === 'left' ? this.nodes.leftUpperArm : this.nodes.rightUpperArm;
    const outerNode = outerArm === 'left' ? this.nodes.leftUpperArm : this.nodes.rightUpperArm;

    if (innerNode) {
      innerNode.rotation.z = innerSign * 0.32;
      innerNode.rotation.x = Math.sin(t) * 0.08;
    }
    if (outerNode) {
      outerNode.rotation.x = -legAngle * 0.6;
      outerNode.rotation.z = -innerSign * 0.14;
    }
  }

  animateLookPartner(delta) {
    const lookAngle = this.isGirl ? -0.45 : 0.45;
    if (this.nodes.head) {
      this.nodes.head.rotation.y = this.THREE.MathUtils.lerp(this.nodes.head.rotation.y, lookAngle, delta * 4.0);
      this.nodes.head.rotation.z = this.THREE.MathUtils.lerp(this.nodes.head.rotation.z, lookAngle * 0.15, delta * 4.0);
    }
  }
}
