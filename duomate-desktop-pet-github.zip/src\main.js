const { app, BrowserWindow, ipcMain, Tray, Menu, screen, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');

const LOG_FILE = path.join(app.getPath('userData'), 'duomate-debug.log');
const LOCAL_LOG = path.join(__dirname, '..', 'duomate-debug.log');

function debugLog(msg) {
  try {
    const formatted = `[${new Date().toISOString()}] ${msg}\n`;
    fs.appendFileSync(LOG_FILE, formatted);
    fs.appendFileSync(LOCAL_LOG, formatted);
    console.log(msg);
  } catch (e) {}
}

process.on('uncaughtException', (err) => {
  debugLog(`[UNCAUGHT EXCEPTION] ${err.stack || err}`);
});
process.on('unhandledRejection', (reason) => {
  debugLog(`[UNHANDLED REJECTION] ${reason?.stack || reason}`);
});

debugLog('Main process started.');

const HardwareMonitor = require('./monitor');
const ReminderManager = require('./reminders');

let petWindow = null;
let settingsWindow = null;
let tray = null;
let monitor = null;
let reminders = null;

const SETTINGS_FILE = path.join(app.getPath('userData'), 'duomate-settings.json');

const DEFAULT_SETTINGS = {
  windowX: null,
  windowY: null,
  petScale: 'medium', // small, medium, large
  mohanOffsetX: -0.55,
  companionOffsetX: 0.55,
  voiceEnabled: true,
  voiceVolume: 0.85,
  voicePitch: 1.15,
  voiceRate: 1.0,
  voiceName: '',
  waterReminderEnabled: true,
  waterIntervalMin: 45,
  breakReminderEnabled: true,
  workDurationMin: 50,
  breakDurationMin: 10,
  systemMonitoringEnabled: true,
  notificationEnabled: true,
  startWithWindows: false,
  romanticInteractionsEnabled: true,
  romanticIntervalMin: 3
};

function loadSettings() {
  try {
    if (fs.existsSync(SETTINGS_FILE)) {
      const data = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8'));
      return { ...DEFAULT_SETTINGS, ...data };
    }
  } catch (err) {
    console.error('Error loading settings:', err);
  }
  return { ...DEFAULT_SETTINGS };
}

let currentSettings = loadSettings();

function saveSettings(newSettings) {
  currentSettings = { ...currentSettings, ...newSettings };
  try {
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify(currentSettings, null, 2), 'utf8');
  } catch (err) {
    console.error('Error saving settings:', err);
  }

  // Sync with background managers
  if (monitor) {
    monitor.setEnabled(currentSettings.systemMonitoringEnabled && currentSettings.notificationEnabled);
  }
  if (reminders) {
    reminders.updateSettings({
      waterEnabled: currentSettings.waterReminderEnabled && currentSettings.notificationEnabled,
      waterIntervalMin: currentSettings.waterIntervalMin,
      breakEnabled: currentSettings.breakReminderEnabled && currentSettings.notificationEnabled,
      workDurationMin: currentSettings.workDurationMin,
      breakDurationMin: currentSettings.breakDurationMin
    });
  }

  // Update Login Item settings
  try {
    app.setLoginItemSettings({
      openAtLogin: !!currentSettings.startWithWindows,
      path: process.execPath
    });
  } catch (e) {
    // ignore on dev
  }

  // Notify windows
  if (petWindow && !petWindow.isDestroyed()) {
    petWindow.webContents.send('settings-updated', currentSettings);
  }
  if (settingsWindow && !settingsWindow.isDestroyed()) {
    settingsWindow.webContents.send('settings-updated', currentSettings);
  }

  return currentSettings;
}

function getWindowDimensions(scale) {
  switch (scale) {
    case 'small':
      return { width: 400, height: 320 };
    case 'large':
      return { width: 620, height: 480 };
    case 'medium':
    default:
      return { width: 500, height: 390 };
  }
}

function getAssetPath(...parts) {
  const p = path.join(__dirname, '..', ...parts);
  const unpacked = p.replace('app.asar', 'app.asar.unpacked');
  if (fs.existsSync(unpacked)) return unpacked;
  return p;
}

function createPetWindow() {
  const { width, height } = getWindowDimensions(currentSettings.petScale);
  const primaryDisplay = screen.getPrimaryDisplay();
  const { workArea } = primaryDisplay;

  let x = currentSettings.windowX;
  let y = currentSettings.windowY;

  // Default to bottom-right corner of screen
  if (typeof x !== 'number' || typeof y !== 'number') {
    x = Math.round(workArea.x + workArea.width - width - 40);
    y = Math.round(workArea.y + workArea.height - height - 40);
    currentSettings.windowX = x;
    currentSettings.windowY = y;
  }

  const iconPath = getAssetPath('assets', 'icons', 'icon.ico');

  petWindow = new BrowserWindow({
    width,
    height,
    x,
    y,
    show: true,
    transparent: true,
    frame: false,
    alwaysOnTop: true,
    hasShadow: false,
    resizable: false,
    skipTaskbar: false,
    icon: iconPath,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webSecurity: false
    }
  });

  try {
    petWindow.setAlwaysOnTop(true, 'screen-saver');
    petWindow.setVisibleOnAllWorkspaces(true);
  } catch (e) {}

  petWindow.loadFile(path.join(__dirname, 'pet.html'));
  petWindow.show();
  petWindow.focus();

  petWindow.webContents.on('did-fail-load', (e, code, desc, url) => {
    console.error('PET WINDOW FAILED TO LOAD:', code, desc, url);
  });

  petWindow.webContents.on('console-message', (e, level, message, line, sourceId) => {
    debugLog(`[Pet Window Console ${level}] ${message} (${sourceId}:${line})`);
  });

  if (process.argv.includes('--screenshot')) {
    setTimeout(async () => {
      try {
        const image = await petWindow.webContents.capturePage();
        const outPath = path.join(__dirname, '..', 'pet-render-preview.png');
        fs.writeFileSync(outPath, image.toPNG());
        debugLog(`Saved screenshot to ${outPath} successfully!`);
        app.quit();
      } catch (err) {
        debugLog(`Screenshot error: ${err.message}`);
        app.quit();
      }
    }, 2800);
  }

  petWindow.on('close', (e) => {
    debugLog(`petWindow close event! Stack: ${new Error().stack}`);
  });

  petWindow.on('closed', () => {
    debugLog('petWindow closed event!');
    petWindow = null;
  });

  petWindow.on('moved', () => {
    if (!petWindow.isDestroyed()) {
      const pos = petWindow.getPosition();
      currentSettings.windowX = pos[0];
      currentSettings.windowY = pos[1];
      saveSettings(currentSettings);
    }
  });

  petWindow.on('closed', () => {
    petWindow = null;
  });
}

function createSettingsWindow() {
  if (settingsWindow && !settingsWindow.isDestroyed()) {
    settingsWindow.show();
    settingsWindow.focus();
    return;
  }

  settingsWindow = new BrowserWindow({
    width: 580,
    height: 720,
    title: 'DuoMate Settings',
    resizable: false,
    minimizable: true,
    autoHideMenuBar: true,
    icon: path.join(__dirname, '../assets/icons/icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webSecurity: false
    }
  });

  settingsWindow.loadFile(path.join(__dirname, 'settings.html'));

  settingsWindow.on('closed', () => {
    settingsWindow = null;
  });
}

function createTray() {
  try {
    const icoPath = getAssetPath('assets', 'icons', 'icon.ico');
    const pngPath = getAssetPath('assets', 'icons', 'icon.png');
    let trayIcon = nativeImage.createFromPath(icoPath);
    if (trayIcon.isEmpty()) {
      trayIcon = nativeImage.createFromPath(pngPath).resize({ width: 16, height: 16 });
    }
    tray = new Tray(trayIcon);
    tray.setToolTip('DuoMate – 3D Desktop Couple Pet');
  } catch (err) {
    debugLog(`Tray creation fallback error: ${err.message}`);
    return;
  }

  const contextMenu = Menu.buildFromTemplate([
    { label: 'DuoMate Desktop Pet', enabled: false },
    { type: 'separator' },
    {
      label: 'Open Settings',
      click: () => createSettingsWindow()
    },
    {
      label: 'Couple Actions',
      submenu: [
        { label: 'Romantic Hug 💕', click: () => triggerPetAction('hug') },
        { label: 'Hold Hands 🤝', click: () => triggerPetAction('hold_hands') },
        { label: 'Couple Walk 🚶‍♂️🚶‍♀️', click: () => triggerPetAction('couple_walk') },
        { label: 'Sit Down 🪑', click: () => triggerPetAction('sit') },
        { label: 'Idle / Stand Up ✨', click: () => triggerPetAction('idle') },
        { label: 'Blush & Smile 😊', click: () => triggerPetAction('blush') }
      ]
    },
    {
      label: 'Voice Mute / Unmute',
      type: 'checkbox',
      checked: currentSettings.voiceEnabled,
      click: (item) => {
        saveSettings({ voiceEnabled: item.checked });
      }
    },
    {
      label: 'Reset Pet Position',
      click: () => {
        const primary = screen.getPrimaryDisplay();
        const { width, height } = getWindowDimensions(currentSettings.petScale);
        const nx = Math.round(primary.workArea.x + primary.workArea.width - width - 40);
        const ny = Math.round(primary.workArea.y + primary.workArea.height - height - 40);
        if (petWindow && !petWindow.isDestroyed()) {
          petWindow.setPosition(nx, ny);
        }
        saveSettings({ windowX: nx, windowY: ny, mohanOffsetX: -0.55, companionOffsetX: 0.55 });
      }
    },
    { type: 'separator' },
    {
      label: 'Hide Pet',
      click: () => {
        if (petWindow && !petWindow.isDestroyed()) {
          if (petWindow.isVisible()) {
            petWindow.hide();
          } else {
            petWindow.show();
          }
        }
      }
    },
    {
      label: 'Exit DuoMate',
      click: () => {
        app.quit();
      }
    }
  ]);

  tray.setContextMenu(contextMenu);
  tray.on('double-click', () => {
    if (petWindow && !petWindow.isDestroyed()) {
      petWindow.show();
      petWindow.focus();
    }
  });
}

function triggerPetAction(action) {
  if (petWindow && !petWindow.isDestroyed()) {
    petWindow.webContents.send('trigger-action', action);
  }
}

function sendPetNotification(type, message, title = 'DuoMate AI') {
  if (!currentSettings.notificationEnabled) return;
  if (petWindow && !petWindow.isDestroyed()) {
    petWindow.webContents.send('pet-notification', { type, message, title });
  }
}

// Setup Hardware Monitor & Reminders
function initBackgroundServices() {
  monitor = new HardwareMonitor((type, message) => {
    sendPetNotification(type, message, 'PC Alert ⚡');
  });
  monitor.setEnabled(currentSettings.systemMonitoringEnabled && currentSettings.notificationEnabled);
  monitor.start(4000);

  reminders = new ReminderManager((type, message, title) => {
    sendPetNotification(type, message, title);
  });
  reminders.updateSettings({
    waterEnabled: currentSettings.waterReminderEnabled && currentSettings.notificationEnabled,
    waterIntervalMin: currentSettings.waterIntervalMin,
    breakEnabled: currentSettings.breakReminderEnabled && currentSettings.notificationEnabled,
    workDurationMin: currentSettings.workDurationMin,
    breakDurationMin: currentSettings.breakDurationMin
  });
  reminders.start();
}

// IPC Handlers
ipcMain.handle('get-settings', () => currentSettings);

ipcMain.handle('save-settings', (event, newSettings) => {
  const updated = saveSettings(newSettings);
  // If scale changed, resize window
  if (newSettings.petScale && petWindow && !petWindow.isDestroyed()) {
    const { width, height } = getWindowDimensions(newSettings.petScale);
    petWindow.setSize(width, height);
  }
  return updated;
});

ipcMain.handle('get-hardware-stats', async () => {
  if (monitor) {
    return monitor.getStats();
  }
  return null;
});

ipcMain.on('move-window', (event, { dx, dy }) => {
  if (petWindow && !petWindow.isDestroyed()) {
    const [x, y] = petWindow.getPosition();
    petWindow.setPosition(Math.round(x + dx), Math.round(y + dy));
  }
});

ipcMain.on('save-pet-positions', (event, { mohanOffsetX, companionOffsetX }) => {
  saveSettings({ mohanOffsetX, companionOffsetX });
});

ipcMain.on('open-settings', () => createSettingsWindow());

ipcMain.on('close-app', () => app.quit());

ipcMain.on('minimize-pet', () => {
  if (petWindow && !petWindow.isDestroyed()) petWindow.hide();
});

ipcMain.on('test-reminder', (event, type) => {
  if (reminders) {
    if (type === 'water') reminders.triggerTestWater();
    if (type === 'break') reminders.triggerTestBreak();
  }
});

ipcMain.on('trigger-interaction', (event, action) => {
  triggerPetAction(action);
});

// App Lifecycle
app.whenReady().then(() => {
  debugLog('app.whenReady reached. Creating pet window...');
  try {
    createPetWindow();
    debugLog('createPetWindow completed.');
  } catch (err) {
    debugLog(`createPetWindow ERROR: ${err.stack || err}`);
  }

  try {
    createTray();
    debugLog('createTray completed.');
  } catch (err) {
    debugLog(`createTray ERROR: ${err.stack || err}`);
  }

  try {
    initBackgroundServices();
    debugLog('initBackgroundServices completed.');
  } catch (err) {
    debugLog(`initBackgroundServices ERROR: ${err.stack || err}`);
  }

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createPetWindow();
    }
  });
}).catch(err => {
  debugLog(`app.whenReady rejection: ${err.stack || err}`);
});

app.on('window-all-closed', () => {
  debugLog('app window-all-closed triggered.');
});

app.on('before-quit', (e) => {
  debugLog(`app before-quit triggered! Stack: ${new Error().stack}`);
  if (monitor) monitor.stop();
  if (reminders) reminders.stop();
});

app.on('will-quit', () => {
  debugLog('app will-quit triggered!');
});

app.on('quit', (e, code) => {
  debugLog(`app quit triggered with code: ${code}`);
});
