// DuoMate Settings Logic
const voiceEnabled = document.getElementById('voice-enabled');
const voiceVolume = document.getElementById('voice-volume');
const volVal = document.getElementById('vol-val');
const petScale = document.getElementById('pet-scale');
const romanticEnabled = document.getElementById('romantic-enabled');
const romanticInterval = document.getElementById('romantic-interval');
const waterEnabled = document.getElementById('water-enabled');
const waterInterval = document.getElementById('water-interval');
const breakEnabled = document.getElementById('break-enabled');
const workDuration = document.getElementById('work-duration');
const breakDuration = document.getElementById('break-duration');
const monitorEnabled = document.getElementById('monitor-enabled');
const notificationEnabled = document.getElementById('notification-enabled');
const startupEnabled = document.getElementById('startup-enabled');
const btnSave = document.getElementById('btn-save-settings');
const btnTestWater = document.getElementById('btn-test-water');
const btnTestBreak = document.getElementById('btn-test-break');
const saveToast = document.getElementById('save-toast');

// Live Stats Elements
const statCpuLoad = document.getElementById('stat-cpu-load');
const statCpuTemp = document.getElementById('stat-cpu-temp');
const statRam = document.getElementById('stat-ram');
const statBat = document.getElementById('stat-bat');

// Update Volume Label
voiceVolume.addEventListener('input', () => {
  volVal.textContent = `${voiceVolume.value}%`;
});

// Load Initial Settings
async function loadSettings() {
  if (!window.duomate) return;
  const s = await window.duomate.getSettings();
  if (!s) return;

  voiceEnabled.checked = !!s.voiceEnabled;
  voiceVolume.value = Math.round((s.voiceVolume || 0.85) * 100);
  volVal.textContent = `${voiceVolume.value}%`;

  petScale.value = s.petScale || 'medium';
  romanticEnabled.checked = s.romanticInteractionsEnabled !== false;
  romanticInterval.value = s.romanticIntervalMin || 3;

  waterEnabled.checked = s.waterReminderEnabled !== false;
  waterInterval.value = s.waterIntervalMin || 45;

  breakEnabled.checked = s.breakReminderEnabled !== false;
  workDuration.value = s.workDurationMin || 50;
  breakDuration.value = s.breakDurationMin || 10;

  monitorEnabled.checked = s.systemMonitoringEnabled !== false;
  notificationEnabled.checked = s.notificationEnabled !== false;
  startupEnabled.checked = !!s.startWithWindows;
}

// Save Settings
async function saveSettings() {
  if (!window.duomate) return;

  const newSettings = {
    voiceEnabled: voiceEnabled.checked,
    voiceVolume: parseInt(voiceVolume.value, 10) / 100,
    petScale: petScale.value,
    romanticInteractionsEnabled: romanticEnabled.checked,
    romanticIntervalMin: parseInt(romanticInterval.value, 10) || 3,
    waterReminderEnabled: waterEnabled.checked,
    waterIntervalMin: parseInt(waterInterval.value, 10) || 45,
    breakReminderEnabled: breakEnabled.checked,
    workDurationMin: parseInt(workDuration.value, 10) || 50,
    breakDurationMin: parseInt(breakDuration.value, 10) || 10,
    systemMonitoringEnabled: monitorEnabled.checked,
    notificationEnabled: notificationEnabled.checked,
    startWithWindows: startupEnabled.checked
  };

  await window.duomate.saveSettings(newSettings);

  // Show Toast
  saveToast.classList.add('show');
  setTimeout(() => saveToast.classList.remove('show'), 2400);
}

btnSave.addEventListener('click', saveSettings);

// Test Reminder Triggers
btnTestWater.addEventListener('click', () => {
  if (window.duomate) window.duomate.testReminder('water');
});

btnTestBreak.addEventListener('click', () => {
  if (window.duomate) window.duomate.testReminder('break');
});

// Live Stats Updater
async function updateLiveStats() {
  if (!window.duomate) return;
  try {
    const stats = await window.duomate.getHardwareStats();
    if (stats) {
      statCpuLoad.textContent = stats.cpuUsage || 'Unavailable';
      statCpuTemp.textContent = stats.cpuTemp || 'Unavailable';
      statRam.textContent = stats.ramUsage || 'Unavailable';
      statBat.textContent = stats.battery || 'Unavailable';
    }
  } catch (e) {
    // ignore
  }
}

// Initial Call & Live Polling
loadSettings();
updateLiveStats();
setInterval(updateLiveStats, 3000);
