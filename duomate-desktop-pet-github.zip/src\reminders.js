class ReminderManager {
  constructor(onNotify) {
    this.onNotify = onNotify; // Callback: (type, message, title)
    this.waterEnabled = true;
    this.waterIntervalMin = 45; // minutes
    this.waterTimer = null;

    this.breakEnabled = true;
    this.workDurationMin = 50; // minutes
    this.breakDurationMin = 10; // minutes
    this.breakTimer = null;
    this.isBreakActive = false;
  }

  start() {
    this.resetWaterTimer();
    this.resetBreakTimer();
  }

  stop() {
    if (this.waterTimer) clearTimeout(this.waterTimer);
    if (this.breakTimer) clearTimeout(this.breakTimer);
    this.waterTimer = null;
    this.breakTimer = null;
  }

  updateSettings({ waterEnabled, waterIntervalMin, breakEnabled, workDurationMin, breakDurationMin }) {
    if (typeof waterEnabled === 'boolean') this.waterEnabled = waterEnabled;
    if (typeof waterIntervalMin === 'number' && waterIntervalMin > 0) this.waterIntervalMin = waterIntervalMin;
    if (typeof breakEnabled === 'boolean') this.breakEnabled = breakEnabled;
    if (typeof workDurationMin === 'number' && workDurationMin > 0) this.workDurationMin = workDurationMin;
    if (typeof breakDurationMin === 'number' && breakDurationMin > 0) this.breakDurationMin = breakDurationMin;

    this.resetWaterTimer();
    this.resetBreakTimer();
  }

  resetWaterTimer() {
    if (this.waterTimer) clearTimeout(this.waterTimer);
    if (!this.waterEnabled) return;

    const ms = this.waterIntervalMin * 60 * 1000;
    this.waterTimer = setTimeout(() => {
      if (this.waterEnabled && this.onNotify) {
        this.onNotify('water', 'Mohan! Water kudikka marandhuteengala? Konjam water kudinga!', 'Hydration Reminder 💧');
      }
      this.resetWaterTimer();
    }, ms);
  }

  resetBreakTimer() {
    if (this.breakTimer) clearTimeout(this.breakTimer);
    if (!this.breakEnabled) return;

    if (this.isBreakActive) {
      // Currently in break, countdown to return to work
      const ms = this.breakDurationMin * 60 * 1000;
      this.breakTimer = setTimeout(() => {
        this.isBreakActive = false;
        if (this.breakEnabled && this.onNotify) {
          this.onNotify('work_resume', "Mohan! Break time mudinjadhu. Let's resume work!", 'Break Ended ⏰');
        }
        this.resetBreakTimer();
      }, ms);
    } else {
      // Currently in work session, countdown to break
      const ms = this.workDurationMin * 60 * 1000;
      this.breakTimer = setTimeout(() => {
        this.isBreakActive = true;
        if (this.breakEnabled && this.onNotify) {
          this.onNotify('break', 'Mohan! Romba nerama work panreenga. Konjam break eduthukonga!', 'Take a Break ☕');
        }
        this.resetBreakTimer();
      }, ms);
    }
  }

  triggerTestWater() {
    if (this.onNotify) {
      this.onNotify('water', 'Mohan! Water kudikka marandhuteengala? Konjam water kudinga!', 'Hydration Test 💧');
    }
  }

  triggerTestBreak() {
    if (this.onNotify) {
      this.onNotify('break', 'Mohan! Romba nerama work panreenga. Konjam break eduthukonga!', 'Break Test ☕');
    }
  }
}

module.exports = ReminderManager;
