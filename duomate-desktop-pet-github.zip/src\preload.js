const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('duomate', {
  // Settings
  getSettings: () => ipcRenderer.invoke('get-settings'),
  saveSettings: (settings) => ipcRenderer.invoke('save-settings', settings),
  onSettingsUpdated: (callback) => {
    ipcRenderer.on('settings-updated', (event, data) => callback(data));
  },

  // Window Movement
  moveWindow: (dx, dy) => ipcRenderer.send('move-window', { dx, dy }),
  savePetPositions: (positions) => ipcRenderer.send('save-pet-positions', positions),

  // Hardware Stats
  getHardwareStats: () => ipcRenderer.invoke('get-hardware-stats'),

  // Actions & Controls
  openSettings: () => ipcRenderer.send('open-settings'),
  closeApp: () => ipcRenderer.send('close-app'),
  minimizeToTray: () => ipcRenderer.send('minimize-pet'),
  testReminder: (type) => ipcRenderer.send('test-reminder', type),
  triggerInteraction: (action) => ipcRenderer.send('trigger-interaction', action),

  // Notifications from main process (Alerts & Reminders)
  onNotification: (callback) => {
    ipcRenderer.on('pet-notification', (event, data) => callback(data));
  },

  // Remote action triggers (from tray or settings)
  onActionTriggered: (callback) => {
    ipcRenderer.on('trigger-action', (event, action) => callback(action));
  }
});
