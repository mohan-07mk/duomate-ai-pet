import * as THREE from './lib/three.module.js';
import { DuoCharacterController, buildMohan, buildCompanion } from './character.js';

console.log('[PET JS] Three.js and Character modules loaded successfully!');

// DOM Elements
const container = document.getElementById('canvas-container');
const speechBubble = document.getElementById('speech-bubble');
const bubbleTitle = document.getElementById('bubble-title');
const bubbleMessage = document.getElementById('bubble-message');
const bubbleIcon = document.getElementById('bubble-icon');
const contextMenu = document.getElementById('context-menu');
const btnHug = document.getElementById('btn-hug');
const btnWalk = document.getElementById('btn-walk');
const btnVoice = document.getElementById('btn-voice');
const btnSettings = document.getElementById('btn-settings');
const windowDragArea = document.getElementById('window-drag-area');

// Three.js State
let scene, camera, renderer;
let mohanModel = null, companionModel = null;
let mohanCtrl = null, companionCtrl = null;
let lastTime = performance.now();
let raycaster = new THREE.Raycaster();
let mouse = new THREE.Vector2();

// Dragging & Interaction State
let isDraggingWindow = false;
let isDraggingCharacter = null; // 'mohan' | 'companion' | null
let dragStartPointer = { x: 0, y: 0 };
let hasMovedPointer = false;
let autoCoupleTimer = null;
let speechTimeout = null;

// Settings cache
let settings = {
  voiceEnabled: true,
  voiceVolume: 0.85,
  voicePitch: 1.15,
  voiceRate: 1.0,
  mohanOffsetX: -0.55,
  companionOffsetX: 0.55,
  romanticInteractionsEnabled: true,
  romanticIntervalMin: 3
};

// Available Voices
let femaleVoice = null;

// Initialize Web Speech API Voices
function initVoices() {
  if (!('speechSynthesis' in window)) return;
  const updateVoices = () => {
    const voices = window.speechSynthesis.getVoices();
    // Prioritize English female voices
    femaleVoice = voices.find(v => 
      /zira|jenny|female|samantha|victoria|karen|susan|aria/i.test(v.name)
    ) || voices.find(v => v.lang.startsWith('en')) || voices[0];
  };

  updateVoices();
  window.speechSynthesis.onvoiceschanged = updateVoices;
}

// Speak Notification with Lip Sync and Speech Bubble
function speak(text, title = 'Companion', icon = '💬') {
  showSpeechBubble(text, title, icon);

  if (!settings.voiceEnabled || !('speechSynthesis' in window)) {
    // Bubble only if muted
    if (speechTimeout) clearTimeout(speechTimeout);
    speechTimeout = setTimeout(() => hideSpeechBubble(), 4500);
    return;
  }

  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  if (femaleVoice) utterance.voice = femaleVoice;
  utterance.volume = settings.voiceVolume;
  utterance.pitch = settings.voicePitch || 1.15;
  utterance.rate = settings.voiceRate || 1.0;

  utterance.onstart = () => {
    if (companionCtrl) companionCtrl.setTalking(true);
  };

  utterance.onend = () => {
    if (companionCtrl) companionCtrl.setTalking(false);
    if (speechTimeout) clearTimeout(speechTimeout);
    speechTimeout = setTimeout(() => hideSpeechBubble(), 3000);
  };

  utterance.onerror = () => {
    if (companionCtrl) companionCtrl.setTalking(false);
    if (speechTimeout) clearTimeout(speechTimeout);
    speechTimeout = setTimeout(() => hideSpeechBubble(), 3000);
  };

  window.speechSynthesis.speak(utterance);
}

function showSpeechBubble(message, title = 'Companion', icon = '💬') {
  bubbleTitle.textContent = title;
  bubbleMessage.textContent = message;
  bubbleIcon.textContent = icon;
  speechBubble.classList.add('visible');
}

function hideSpeechBubble() {
  speechBubble.classList.remove('visible');
}

// Spawn Romantic Floating Hearts
function spawnHearts(count = 6) {
  for (let i = 0; i < count; i++) {
    setTimeout(() => {
      const heart = document.createElement('div');
      heart.className = 'heart-particle';
      const symbols = ['💕', '💖', '💗', '❤️', '✨'];
      heart.textContent = symbols[Math.floor(Math.random() * symbols.length)];
      heart.style.left = `${160 + (Math.random() * 160)}px`;
      heart.style.top = `${180 + (Math.random() * 60)}px`;
      document.body.appendChild(heart);

      setTimeout(() => heart.remove(), 1800);
    }, i * 220);
  }
}

// Initialize 3D Scene
async function init3D() {
  const width = window.innerWidth;
  const height = window.innerHeight;

  // Scene
  scene = new THREE.Scene();

  // Camera
  camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 100);
  camera.position.set(0, 0.6, 5.0);
  camera.lookAt(0, 0.1, 0);

  // Renderer
  renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: 'low-power' });
  renderer.setSize(width, height);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setClearColor(0x000000, 0);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFShadowMap;
  container.appendChild(renderer.domElement);

  // Lighting
  const ambientLight = new THREE.AmbientLight(0xFFF2E8, 1.25);
  scene.add(ambientLight);

  const mainLight = new THREE.DirectionalLight(0xFFFFFF, 1.4);
  mainLight.position.set(2.5, 4.5, 3.5);
  mainLight.castShadow = true;
  mainLight.shadow.mapSize.width = 1024;
  mainLight.shadow.mapSize.height = 1024;
  scene.add(mainLight);

  const fillLight = new THREE.DirectionalLight(0xE0EBFF, 0.85);
  fillLight.position.set(-2.5, 3.0, 2.0);
  scene.add(fillLight);

  const hemiLight = new THREE.HemisphereLight(0xFFFAF0, 0xD4C4B5, 0.65);
  scene.add(hemiLight);

  // Soft Contact Shadow Plane under feet
  const shadowGeo = new THREE.PlaneGeometry(3.5, 1.6);
  const shadowCanvas = document.createElement('canvas');
  shadowCanvas.width = 128;
  shadowCanvas.height = 128;
  const sCtx = shadowCanvas.getContext('2d');
  const gradient = sCtx.createRadialGradient(64, 64, 10, 64, 64, 60);
  gradient.addColorStop(0, 'rgba(50, 15, 25, 0.45)');
  gradient.addColorStop(0.5, 'rgba(50, 15, 25, 0.2)');
  gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
  sCtx.fillStyle = gradient;
  sCtx.fillRect(0, 0, 128, 128);

  const shadowTexture = new THREE.CanvasTexture(shadowCanvas);
  const shadowMat = new THREE.MeshBasicMaterial({
    map: shadowTexture,
    transparent: true,
    opacity: 0.7,
    depthWrite: false
  });
  const shadowPlane = new THREE.Mesh(shadowGeo, shadowMat);
  shadowPlane.rotation.x = -Math.PI * 0.5;
  shadowPlane.position.y = -1.48;
  scene.add(shadowPlane);

  // Load Models
  await loadCharacters();

  // Setup Event Listeners
  setupInteractions();

  // Start Animation Loop
  animate();
  console.log('init3D completed successfully, animation loop running.');
}

function loadCharacters() {
  try {
    console.log('Building Mohan 3D Model...');
    // 1. Build Mohan 3D Model
    mohanModel = buildMohan(THREE);
    mohanModel.scale.set(0.92, 0.92, 0.92);
    mohanModel.position.set(settings.mohanOffsetX, -1.45, 0);
    scene.add(mohanModel);
    mohanCtrl = new DuoCharacterController(mohanModel, false, THREE);
    console.log('Mohan 3D Model added to scene.');

    console.log('Building AI Companion 3D Model...');
    // 2. Build AI Companion 3D Model
    companionModel = buildCompanion(THREE);
    companionModel.scale.set(0.92, 0.92, 0.92);
    companionModel.position.set(settings.companionOffsetX, -1.45, 0);
    scene.add(companionModel);
    companionCtrl = new DuoCharacterController(companionModel, true, THREE);
    console.log('AI Companion 3D Model added to scene.');

    // Initial greeting
    setTimeout(() => {
      speak("Hi Mohan! DuoMate is active and keeping your PC running smooth!", "AI Companion", "💖");
    }, 1200);

    // Start Automatic Romantic Interactions
    scheduleNextCoupleInteraction();

  } catch (err) {
    console.error('Error constructing 3D character models:', err);
  }
}

// Automatic Romantic Interaction Routine
function performRomanticInteraction() {
  if (!mohanCtrl || !companionCtrl || !settings.romanticInteractionsEnabled) return;

  // 1. Look at each other
  companionCtrl.playAction('look_at_each_other');
  mohanCtrl.playAction('look_at_each_other');
  companionCtrl.playAction('smile');
  mohanCtrl.playAction('smile');

  // 2. Companion walks toward Mohan
  const targetX = mohanModel.position.x + 0.58;
  const startX = companionModel.position.x;
  companionCtrl.playAction('walk');

  let walkProgress = 0;
  const walkInterval = setInterval(() => {
    walkProgress += 0.05;
    companionModel.position.x = THREE.MathUtils.lerp(startX, targetX, walkProgress);

    if (walkProgress >= 1.0) {
      clearInterval(walkInterval);
      companionModel.position.x = targetX;

      // 3. Romantic Hug / Holding Hands
      const isHug = Math.random() > 0.4;
      if (isHug) {
        companionCtrl.playAction('hug');
        mohanCtrl.playAction('hug');
        companionCtrl.playAction('blush');
        mohanCtrl.playAction('blush');
        spawnHearts(8);
      } else {
        companionCtrl.playAction('hold_hands');
        mohanCtrl.playAction('hold_hands');
        spawnHearts(5);
      }

      // 4. Walk Together
      setTimeout(() => {
        companionCtrl.playAction('couple_walk');
        mohanCtrl.playAction('couple_walk');

        // Couple walks gently side-to-side
        let coupleT = 0;
        const coupleWalkInterval = setInterval(() => {
          coupleT += 0.04;
          const shift = Math.sin(coupleT) * 0.006;
          mohanModel.position.x += shift;
          companionModel.position.x += shift;

          if (coupleT >= 4.0) {
            clearInterval(coupleWalkInterval);
            // Return to rest positions
            returnToDefaultPositions();
          }
        }, 50);

      }, 3500);
    }
  }, 40);
}

function returnToDefaultPositions() {
  if (!mohanModel || !companionModel) return;

  companionCtrl.playAction('walk');
  mohanCtrl.playAction('idle');

  let resetT = 0;
  const fromX = companionModel.position.x;
  const toX = settings.companionOffsetX;
  const fromMohanX = mohanModel.position.x;
  const toMohanX = settings.mohanOffsetX;

  const returnInterval = setInterval(() => {
    resetT += 0.05;
    companionModel.position.x = THREE.MathUtils.lerp(fromX, toX, resetT);
    mohanModel.position.x = THREE.MathUtils.lerp(fromMohanX, toMohanX, resetT);

    if (resetT >= 1.0) {
      clearInterval(returnInterval);
      companionModel.position.x = toX;
      mohanModel.position.x = toMohanX;
      companionCtrl.playAction('idle');
      mohanCtrl.playAction('idle');
    }
  }, 40);
}

function scheduleNextCoupleInteraction() {
  if (autoCoupleTimer) clearTimeout(autoCoupleTimer);
  const minutes = settings.romanticIntervalMin || 3;
  autoCoupleTimer = setTimeout(() => {
    performRomanticInteraction();
    scheduleNextCoupleInteraction();
  }, minutes * 60 * 1000);
}

// Mouse and Drag-and-Drop Interactions
function setupInteractions() {
  let isPointerDown = false;
  let clickedTarget = null;
  let lastScreenX = 0, lastScreenY = 0;

  window.addEventListener('mousedown', (e) => {
    if (e.target.closest('#speech-bubble') || e.target.closest('.quick-actions') || e.target.closest('#context-menu')) {
      return;
    }

    // Hide context menu on left click
    contextMenu.style.display = 'none';

    if (e.button === 2) {
      // Right click -> Show custom context menu
      contextMenu.style.left = `${Math.min(e.clientX, window.innerWidth - 180)}px`;
      contextMenu.style.top = `${Math.min(e.clientY, window.innerHeight - 260)}px`;
      contextMenu.style.display = 'block';
      return;
    }

    if (e.button !== 0) return;

    isPointerDown = true;
    hasMovedPointer = false;
    dragStartPointer.x = e.clientX;
    dragStartPointer.y = e.clientY;
    lastScreenX = e.screenX;
    lastScreenY = e.screenY;

    // Check raycast on 3D characters
    mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(e.clientY / window.innerHeight) * 2 + 1;
    raycaster.setFromCamera(mouse, camera);

    const mohanHits = mohanModel ? raycaster.intersectObjects(mohanModel.children, true) : [];
    const companionHits = companionModel ? raycaster.intersectObjects(companionModel.children, true) : [];

    if (mohanHits.length > 0) {
      isDraggingCharacter = 'mohan';
      clickedTarget = 'mohan';
    } else if (companionHits.length > 0) {
      isDraggingCharacter = 'companion';
      clickedTarget = 'companion';
    } else {
      // Drag entire window across Windows desktop
      isDraggingWindow = true;
      clickedTarget = 'background';
    }
  });

  window.addEventListener('mousemove', (e) => {
    // Normal hover look-at tracking
    if (!isPointerDown) {
      mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
      mouse.y = -(e.clientY / window.innerHeight) * 2 + 1;
      const targetLook = new THREE.Vector3(mouse.x * 2.5, mouse.y * 1.5, 2.0);
      if (mohanCtrl) mohanCtrl.setLookAt(targetLook, 0.6);
      if (companionCtrl) companionCtrl.setLookAt(targetLook, 0.6);
      return;
    }

    const dist = Math.hypot(e.clientX - dragStartPointer.x, e.clientY - dragStartPointer.y);
    if (dist > 3) hasMovedPointer = true;

    if (isDraggingWindow) {
      const dx = e.screenX - lastScreenX;
      const dy = e.screenY - lastScreenY;
      lastScreenX = e.screenX;
      lastScreenY = e.screenY;
      if (window.duomate && (dx !== 0 || dy !== 0)) {
        window.duomate.moveWindow(dx, dy);
      }
    } else if (isDraggingCharacter === 'mohan' && mohanModel) {
      // Move Mohan in 3D scene
      const deltaX = (e.clientX - dragStartPointer.x) * 0.008;
      mohanModel.position.x = THREE.MathUtils.clamp(settings.mohanOffsetX + deltaX, -1.8, 1.8);
      if (mohanCtrl) mohanCtrl.playAction('walk');
    } else if (isDraggingCharacter === 'companion' && companionModel) {
      // Move Companion in 3D scene
      const deltaX = (e.clientX - dragStartPointer.x) * 0.008;
      companionModel.position.x = THREE.MathUtils.clamp(settings.companionOffsetX + deltaX, -1.8, 1.8);
      if (companionCtrl) companionCtrl.playAction('walk');
    }
  });

  window.addEventListener('mouseup', () => {
    if (!isPointerDown) return;
    isPointerDown = false;

    if (isDraggingCharacter === 'mohan' && mohanModel) {
      settings.mohanOffsetX = mohanModel.position.x;
      if (mohanCtrl) mohanCtrl.playAction('idle');
      if (window.duomate) {
        window.duomate.savePetPositions({
          mohanOffsetX: settings.mohanOffsetX,
          companionOffsetX: settings.companionOffsetX
        });
      }
    } else if (isDraggingCharacter === 'companion' && companionModel) {
      settings.companionOffsetX = companionModel.position.x;
      if (companionCtrl) companionCtrl.playAction('idle');
      if (window.duomate) {
        window.duomate.savePetPositions({
          mohanOffsetX: settings.mohanOffsetX,
          companionOffsetX: settings.companionOffsetX
        });
      }
    }

    // Click handler (when not dragged)
    if (!hasMovedPointer && clickedTarget) {
      if (clickedTarget === 'mohan') {
        if (mohanCtrl) {
          mohanCtrl.playAction('smile');
          mohanCtrl.playAction('blush');
        }
        speak("Mohan is focused and working hard! You got this!", "Mohan & AI", "🌟");
      } else if (clickedTarget === 'companion') {
        if (companionCtrl) {
          companionCtrl.playAction('smile');
          companionCtrl.playAction('blush');
          spawnHearts(3);
        }
        const greetings = [
          "Hi Mohan! Need water or a quick stretch?",
          "I'm keeping your PC cool and running smooth!",
          "Doing great, Mohan! Don't overwork yourself!",
          "I'm right here beside you! 💕"
        ];
        const msg = greetings[Math.floor(Math.random() * greetings.length)];
        speak(msg, "AI Companion", "💖");
      }
    }

    isDraggingWindow = false;
    isDraggingCharacter = null;
    clickedTarget = null;
  });

  // Double Click: Instant Hug
  window.addEventListener('dblclick', () => {
    performRomanticInteraction();
  });

  // Prevent default context menu
  window.addEventListener('contextmenu', (e) => {
    e.preventDefault();
  });

  // Quick Action Buttons
  btnHug.addEventListener('click', () => performRomanticInteraction());
  btnWalk.addEventListener('click', () => {
    if (companionCtrl && mohanCtrl) {
      companionCtrl.playAction('couple_walk');
      mohanCtrl.playAction('couple_walk');
      setTimeout(() => {
        companionCtrl.playAction('idle');
        mohanCtrl.playAction('idle');
      }, 4000);
    }
  });

  btnVoice.addEventListener('click', () => {
    settings.voiceEnabled = !settings.voiceEnabled;
    btnVoice.textContent = settings.voiceEnabled ? '🔊' : '🔇';
    if (window.duomate) {
      window.duomate.saveSettings({ voiceEnabled: settings.voiceEnabled });
    }
    speak(settings.voiceEnabled ? "Voice enabled!" : "Voice muted!", "Settings", "🔊");
  });

  btnSettings.addEventListener('click', () => {
    if (window.duomate) window.duomate.openSettings();
  });

  // Context Menu Actions
  contextMenu.addEventListener('click', async (e) => {
    const item = e.target.closest('.menu-item');
    if (!item) return;
    const action = item.dataset.action;
    contextMenu.style.display = 'none';

    switch (action) {
      case 'hug':
        performRomanticInteraction();
        break;
      case 'hold_hands':
        if (companionCtrl && mohanCtrl) {
          companionCtrl.playAction('hold_hands');
          mohanCtrl.playAction('hold_hands');
          spawnHearts(4);
        }
        break;
      case 'couple_walk':
        if (companionCtrl && mohanCtrl) {
          companionCtrl.playAction('couple_walk');
          mohanCtrl.playAction('couple_walk');
          setTimeout(() => {
            companionCtrl.playAction('idle');
            mohanCtrl.playAction('idle');
          }, 4500);
        }
        break;
      case 'sit':
        if (companionCtrl && mohanCtrl) {
          companionCtrl.playAction('sit');
          mohanCtrl.playAction('sit');
        }
        break;
      case 'idle':
        if (companionCtrl && mohanCtrl) {
          companionCtrl.playAction('idle');
          mohanCtrl.playAction('idle');
        }
        break;
      case 'blush':
        if (companionCtrl && mohanCtrl) {
          companionCtrl.playAction('blush');
          mohanCtrl.playAction('blush');
          spawnHearts(5);
        }
        break;
      case 'stats':
        if (window.duomate) {
          const stats = await window.duomate.getHardwareStats();
          if (stats) {
            speak(`CPU: ${stats.cpuUsage}, RAM: ${stats.ramUsage}, Battery: ${stats.battery}`, "PC Health", "⚡");
          }
        }
        break;
      case 'settings':
        if (window.duomate) window.duomate.openSettings();
        break;
      case 'reset':
        settings.mohanOffsetX = -0.55;
        settings.companionOffsetX = 0.55;
        if (mohanModel) mohanModel.position.x = -0.55;
        if (companionModel) companionModel.position.x = 0.55;
        if (window.duomate) {
          window.duomate.savePetPositions({
            mohanOffsetX: -0.55,
            companionOffsetX: 0.55
          });
        }
        break;
      case 'close':
        if (window.duomate) window.duomate.closeApp();
        break;
    }
  });

  // Window Resize
  window.addEventListener('resize', () => {
    const width = window.innerWidth;
    const height = window.innerHeight;
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    renderer.setSize(width, height);
  });
}

// Main Render Loop
function animate() {
  requestAnimationFrame(animate);

  const now = performance.now();
  const delta = Math.min((now - lastTime) / 1000, 0.1);
  lastTime = now;

  if (mohanCtrl) mohanCtrl.update(delta);
  if (companionCtrl) companionCtrl.update(delta);

  renderer.render(scene, camera);
}

// IPC Integration with Main Process
async function initIPC() {
  if (!window.duomate) return;

  // Load initial settings
  const loaded = await window.duomate.getSettings();
  if (loaded) {
    settings = { ...settings, ...loaded };
    btnVoice.textContent = settings.voiceEnabled ? '🔊' : '🔇';
  }

  // Handle incoming notifications (alerts / reminders)
  window.duomate.onNotification((data) => {
    speak(data.message, data.title || 'DuoMate AI', '⚠️');
    if (data.type === 'water') {
      spawnHearts(4);
    }
  });

  // Handle trigger actions from tray or settings
  window.duomate.onActionTriggered((action) => {
    if (action === 'hug') performRomanticInteraction();
    else if (action === 'hold_hands') {
      if (companionCtrl && mohanCtrl) {
        companionCtrl.playAction('hold_hands');
        mohanCtrl.playAction('hold_hands');
        spawnHearts(5);
      }
    } else if (action === 'couple_walk') {
      if (companionCtrl && mohanCtrl) {
        companionCtrl.playAction('couple_walk');
        mohanCtrl.playAction('couple_walk');
      }
    } else if (action === 'sit') {
      if (companionCtrl && mohanCtrl) {
        companionCtrl.playAction('sit');
        mohanCtrl.playAction('sit');
      }
    } else if (action === 'idle') {
      if (companionCtrl && mohanCtrl) {
        companionCtrl.playAction('idle');
        mohanCtrl.playAction('idle');
      }
    } else if (action === 'blush') {
      if (companionCtrl && mohanCtrl) {
        companionCtrl.playAction('blush');
        mohanCtrl.playAction('blush');
        spawnHearts(5);
      }
    }
  });

  // Handle settings update
  window.duomate.onSettingsUpdated((newSettings) => {
    settings = { ...settings, ...newSettings };
    btnVoice.textContent = settings.voiceEnabled ? '🔊' : '🔇';
    scheduleNextCoupleInteraction();
  });
}

// Bootstrapping
initVoices();
initIPC();
init3D();
