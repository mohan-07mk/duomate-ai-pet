@echo off
setlocal
cd /d "%~dp0"
set ELECTRON_RUN_AS_NODE=

echo ========================================================
echo       Starting DuoMate Desktop Pet (Mohan and AI)
echo ========================================================
echo.

if exist "node_modules\electron\dist\electron.exe" (
    echo Launching DuoMate Desktop Pet...
    start "" "node_modules\electron\dist\electron.exe" .
    exit /b 0
)

if exist "dist\win-unpacked\DuoMate Desktop Pet.exe" (
    echo Launching DuoMate Desktop Pet...
    start "" "dist\win-unpacked\DuoMate Desktop Pet.exe"
    exit /b 0
)

echo Launching via npm...
start "" npx electron .
exit /b 0
